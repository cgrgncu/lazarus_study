unit Unit1;

{$mode objfpc}{$H+}

interface

uses
  Classes, SysUtils, Forms, Controls, Graphics, Dialogs, Menus, ComCtrls,
  ExtCtrls, StdCtrls, Grids, TAGraph, TAChartListbox, TASeries;

type

  { TForm1 }

  TForm1 = class(TForm)
    Button1: TButton;
    Button2: TButton;
    Button3: TButton;
    Current_PSU: TLineSeries;
    Current_CH09: TLineSeries;
    Current_CH10: TLineSeries;
    Current_CH11: TLineSeries;
    Current_CH12: TLineSeries;
    Current_CH13: TLineSeries;
    Current_CH14: TLineSeries;
    Current_CH15: TLineSeries;
    Current_CH16: TLineSeries;
    Current_CH17: TLineSeries;
    Current_CH18: TLineSeries;
    Current_CH01: TLineSeries;
    Current_CH19: TLineSeries;
    Current_CH20: TLineSeries;
    Current_CH21: TLineSeries;
    Current_CH22: TLineSeries;
    Current_CH23: TLineSeries;
    Current_CH24: TLineSeries;
    Current_CH25: TLineSeries;
    Current_CH26: TLineSeries;
    Current_CH27: TLineSeries;
    Current_CH28: TLineSeries;
    Current_CH02: TLineSeries;
    Current_CH29: TLineSeries;
    Current_CH30: TLineSeries;
    Current_CH31: TLineSeries;
    Current_CH32: TLineSeries;
    Current_CH33: TLineSeries;
    Current_CH34: TLineSeries;
    Current_CH35: TLineSeries;
    Current_CH36: TLineSeries;
    Current_CH37: TLineSeries;
    Current_CH38: TLineSeries;
    Current_CH03: TLineSeries;
    Current_CH39: TLineSeries;
    Current_CH40: TLineSeries;
    Current_CH41: TLineSeries;
    Current_CH42: TLineSeries;
    Current_CH43: TLineSeries;
    Current_CH44: TLineSeries;
    Current_CH45: TLineSeries;
    Current_CH46: TLineSeries;
    Current_CH47: TLineSeries;
    Current_CH48: TLineSeries;
    Current_CH04: TLineSeries;
    Current_CH49: TLineSeries;
    Current_CH50: TLineSeries;
    Current_CH51: TLineSeries;
    Current_CH52: TLineSeries;
    Current_CH53: TLineSeries;
    Current_CH54: TLineSeries;
    Current_CH55: TLineSeries;
    Current_CH56: TLineSeries;
    Current_CH57: TLineSeries;
    Current_CH58: TLineSeries;
    Current_CH05: TLineSeries;
    Current_CH59: TLineSeries;
    Current_CH60: TLineSeries;
    Current_CH61: TLineSeries;
    Current_CH62: TLineSeries;
    Current_CH63: TLineSeries;
    Current_CH64: TLineSeries;
    Current_CH06: TLineSeries;
    Current_CH07: TLineSeries;
    Current_CH08: TLineSeries;
    Current_ChartListbox: TChartListbox;
    Current_Chart: TChart;
    Current_PopupMenu: TPopupMenu;
    Current_PopupMenu_1_1: TMenuItem;
    Current_PopupMenu_1_2: TMenuItem;
    DMM_SupportedSerialNumbers_GroupBox: TGroupBox;
    DMM_SupportedSerialNumbers_Memo: TMemo;
    ESP32_SupportedSerialNumbers_GroupBox: TGroupBox;
    ESP32_SupportedSerialNumbers_Memo: TMemo;
    Update_Memo: TMemo;
    RunningLog_Memo: TMemo;
    PSU_SupportedSerialNumbers_Memo: TMemo;
    PSU_SupportedSerialNumbers_GroupBox: TGroupBox;
    v299_csv_StringGrid: TStringGrid;
    Voltage_PopupMenu_1_2: TMenuItem;
    Voltage_PopupMenu_1_1: TMenuItem;
    Voltage_PopupMenu: TPopupMenu;
    Voltage_PSU: TLineSeries;
    Voltage_CH09: TLineSeries;
    Voltage_CH10: TLineSeries;
    Voltage_CH11: TLineSeries;
    Voltage_CH12: TLineSeries;
    Voltage_CH13: TLineSeries;
    Voltage_CH14: TLineSeries;
    Voltage_CH15: TLineSeries;
    Voltage_CH16: TLineSeries;
    Voltage_CH17: TLineSeries;
    Voltage_CH18: TLineSeries;
    Voltage_CH01: TLineSeries;
    Voltage_CH19: TLineSeries;
    Voltage_CH20: TLineSeries;
    Voltage_CH21: TLineSeries;
    Voltage_CH22: TLineSeries;
    Voltage_CH23: TLineSeries;
    Voltage_CH24: TLineSeries;
    Voltage_CH25: TLineSeries;
    Voltage_CH26: TLineSeries;
    Voltage_CH27: TLineSeries;
    Voltage_CH28: TLineSeries;
    Voltage_CH02: TLineSeries;
    Voltage_CH29: TLineSeries;
    Voltage_CH30: TLineSeries;
    Voltage_CH31: TLineSeries;
    Voltage_CH32: TLineSeries;
    Voltage_CH33: TLineSeries;
    Voltage_CH34: TLineSeries;
    Voltage_CH35: TLineSeries;
    Voltage_CH36: TLineSeries;
    Voltage_CH37: TLineSeries;
    Voltage_CH38: TLineSeries;
    Voltage_CH03: TLineSeries;
    Voltage_CH39: TLineSeries;
    Voltage_CH40: TLineSeries;
    Voltage_CH41: TLineSeries;
    Voltage_CH42: TLineSeries;
    Voltage_CH43: TLineSeries;
    Voltage_CH44: TLineSeries;
    Voltage_CH45: TLineSeries;
    Voltage_CH46: TLineSeries;
    Voltage_CH47: TLineSeries;
    Voltage_CH48: TLineSeries;
    Voltage_CH04: TLineSeries;
    Voltage_CH49: TLineSeries;
    Voltage_CH50: TLineSeries;
    Voltage_CH51: TLineSeries;
    Voltage_CH52: TLineSeries;
    Voltage_CH53: TLineSeries;
    Voltage_CH54: TLineSeries;
    Voltage_CH55: TLineSeries;
    Voltage_CH56: TLineSeries;
    Voltage_CH57: TLineSeries;
    Voltage_CH58: TLineSeries;
    Voltage_CH05: TLineSeries;
    Voltage_CH59: TLineSeries;
    Voltage_CH60: TLineSeries;
    Voltage_CH61: TLineSeries;
    Voltage_CH62: TLineSeries;
    Voltage_CH63: TLineSeries;
    Voltage_CH64: TLineSeries;
    Voltage_CH06: TLineSeries;
    Voltage_CH07: TLineSeries;
    Voltage_CH08: TLineSeries;
    Voltage_ChartListbox: TChartListbox;
    Voltage_Chart: TChart;
    CheckExternalDevices_Button: TButton;
    DMM_SN_Edit: TEdit;
    DMM_Edit: TEdit;
    CurrentChart_Panel: TPanel;
    VoltageChart_Panel: TPanel;
    PSU_Edit: TEdit;
    PSU_GroupBox: TGroupBox;
    PSU_SN_Edit: TEdit;
    ESP32_Edit: TEdit;
    ESP32_SN_Edit: TEdit;
    ERT_Project_Name_Edit: TEdit;
    ERT_Profile_Name_Edit: TEdit;
    ERT_Profile_Name_GroupBox: TGroupBox;
    ERT_Project_Name_GroupBox: TGroupBox;
    DMM_SN_GroupBox: TGroupBox;
    DMM_GroupBox: TGroupBox;
    ESP32_SN_GroupBox: TGroupBox;
    ESP32_GroupBox: TGroupBox;
    PSU_SN_GroupBox: TGroupBox;
    R2MS_Lite_Controller_SavePath_Edit: TEdit;
    R2MS_Lite_Controller_OpenSavePath_Button: TButton;
    R2MS_Lite_Controller_SavePath_Label: TLabel;
    R2MS_Lite_Controller_GroupBox: TGroupBox;
    MainMenu1: TMainMenu;
    MainMenu1_1: TMenuItem;
    MainMenu1_1_1: TMenuItem;
    EmptyPanel: TPanel;
    PageControl1: TPageControl;
    ScrollBox1: TScrollBox;
    StatusBar1: TStatusBar;
    TabSheet1: TTabSheet;
    TabSheet2: TTabSheet;
    TabSheet3: TTabSheet;
    TabSheet4: TTabSheet;
    TabSheet5: TTabSheet;
    TabSheet6: TTabSheet;
    ToolBar1: TToolBar;
    HorizontalChartLayout_ToolButton: TToolButton;
    CurrentChartOnlyLayout_ToolButton: TToolButton;
    VoltageChartOnlyLayout_ToolButton: TToolButton;
    VerticalChartLayout_ToolButton: TToolButton;
    procedure CurrentChartOnlyLayout_ToolButtonClick(Sender: TObject);
    procedure CurrentChart_PanelResize(Sender: TObject);
    procedure Current_PopupMenu_1_1Click(Sender: TObject);
    procedure Current_PopupMenu_1_2Click(Sender: TObject);
    procedure FormCreate(Sender: TObject);
    procedure HorizontalChartLayout_ToolButtonClick(Sender: TObject);
    procedure MainMenu1_1_1Click(Sender: TObject);
    procedure StatusBar1Resize(Sender: TObject);
    procedure VerticalChartLayout_ToolButtonClick(Sender: TObject);
    procedure VoltageChartOnlyLayout_ToolButtonClick(Sender: TObject);
    procedure VoltageChart_PanelResize(Sender: TObject);
    procedure Voltage_PopupMenu_1_1Click(Sender: TObject);
    procedure Voltage_PopupMenu_1_2Click(Sender: TObject);
  private

  public

  end;

var
  Form1: TForm1;

implementation
//--------------------------------------------------------------------------
//宣告全域變數 add by HsiupoYeh
var
  version_str: AnsiString;
  Current_Folder_Path: AnsiString;
//--------------------------------------------------------------------------

{$R *.lfm}

{ TForm1 }

procedure TForm1.FormCreate(Sender: TObject);
begin
  //--------------------------------------------------------------------------
  // 在這裡對全域變數進行初始化
  version_str := 'v202060713a';
  Current_Folder_Path := ExtractFilePath(Application.ExeName);
  //--------------------------------------------------------------------------
  //--------------------------------------------------------------------------
  // 表單標題追加版本
  Form1.Caption := Form1.Caption + ' ' + version_str;
  //--------------------------------------------------------------------------
end;

procedure TForm1.CurrentChartOnlyLayout_ToolButtonClick(Sender: TObject);
begin
  VoltageChart_Panel.Align := alNone;
  VoltageChart_Panel.Visible := False;
  CurrentChart_Panel.Align := alClient;
  CurrentChart_Panel.Visible := True;
end;

procedure TForm1.CurrentChart_PanelResize(Sender: TObject);
begin
  // 檢查是否處於垂直分割模式 (ToolButton.Down 狀態)
  if VerticalChartLayout_ToolButton.Down then
  begin
    VoltageChart_Panel.Width := (VoltageChart_Panel.Width + CurrentChart_Panel.Width) div 2;
  end
  // 檢查是否處於水平分割模式
  else if HorizontalChartLayout_ToolButton.Down then
  begin
    VoltageChart_Panel.Height := (VoltageChart_Panel.Height + CurrentChart_Panel.Height) div 2;
  end;
end;

procedure TForm1.Current_PopupMenu_1_1Click(Sender: TObject);
begin
  Current_PSU.Active := True;
  Current_CH01.Active := True;
  Current_CH02.Active := True;
  Current_CH03.Active := True;
  Current_CH04.Active := True;
  Current_CH05.Active := True;
  Current_CH06.Active := True;
  Current_CH07.Active := True;
  Current_CH08.Active := True;
  Current_CH09.Active := True;
  Current_CH10.Active := True;
  Current_CH11.Active := True;
  Current_CH12.Active := True;
  Current_CH13.Active := True;
  Current_CH14.Active := True;
  Current_CH15.Active := True;
  Current_CH16.Active := True;
  Current_CH17.Active := True;
  Current_CH18.Active := True;
  Current_CH19.Active := True;
  Current_CH20.Active := True;
  Current_CH21.Active := True;
  Current_CH22.Active := True;
  Current_CH23.Active := True;
  Current_CH24.Active := True;
  Current_CH25.Active := True;
  Current_CH26.Active := True;
  Current_CH27.Active := True;
  Current_CH28.Active := True;
  Current_CH29.Active := True;
  Current_CH30.Active := True;
  Current_CH31.Active := True;
  Current_CH32.Active := True;
  Current_CH33.Active := True;
  Current_CH34.Active := True;
  Current_CH35.Active := True;
  Current_CH36.Active := True;
  Current_CH37.Active := True;
  Current_CH38.Active := True;
  Current_CH39.Active := True;
  Current_CH40.Active := True;
  Current_CH41.Active := True;
  Current_CH42.Active := True;
  Current_CH43.Active := True;
  Current_CH44.Active := True;
  Current_CH45.Active := True;
  Current_CH46.Active := True;
  Current_CH47.Active := True;
  Current_CH48.Active := True;
  Current_CH49.Active := True;
  Current_CH50.Active := True;
  Current_CH51.Active := True;
  Current_CH52.Active := True;
  Current_CH53.Active := True;
  Current_CH54.Active := True;
  Current_CH55.Active := True;
  Current_CH56.Active := True;
  Current_CH57.Active := True;
  Current_CH58.Active := True;
  Current_CH59.Active := True;
  Current_CH60.Active := True;
  Current_CH61.Active := True;
  Current_CH62.Active := True;
  Current_CH63.Active := True;
  Current_CH64.Active := True;
end;

procedure TForm1.Current_PopupMenu_1_2Click(Sender: TObject);
begin
  Current_PSU.Active := False;
  Current_CH01.Active := False;
  Current_CH02.Active := False;
  Current_CH03.Active := False;
  Current_CH04.Active := False;
  Current_CH05.Active := False;
  Current_CH06.Active := False;
  Current_CH07.Active := False;
  Current_CH08.Active := False;
  Current_CH09.Active := False;
  Current_CH10.Active := False;
  Current_CH11.Active := False;
  Current_CH12.Active := False;
  Current_CH13.Active := False;
  Current_CH14.Active := False;
  Current_CH15.Active := False;
  Current_CH16.Active := False;
  Current_CH17.Active := False;
  Current_CH18.Active := False;
  Current_CH19.Active := False;
  Current_CH20.Active := False;
  Current_CH21.Active := False;
  Current_CH22.Active := False;
  Current_CH23.Active := False;
  Current_CH24.Active := False;
  Current_CH25.Active := False;
  Current_CH26.Active := False;
  Current_CH27.Active := False;
  Current_CH28.Active := False;
  Current_CH29.Active := False;
  Current_CH30.Active := False;
  Current_CH31.Active := False;
  Current_CH32.Active := False;
  Current_CH33.Active := False;
  Current_CH34.Active := False;
  Current_CH35.Active := False;
  Current_CH36.Active := False;
  Current_CH37.Active := False;
  Current_CH38.Active := False;
  Current_CH39.Active := False;
  Current_CH40.Active := False;
  Current_CH41.Active := False;
  Current_CH42.Active := False;
  Current_CH43.Active := False;
  Current_CH44.Active := False;
  Current_CH45.Active := False;
  Current_CH46.Active := False;
  Current_CH47.Active := False;
  Current_CH48.Active := False;
  Current_CH49.Active := False;
  Current_CH50.Active := False;
  Current_CH51.Active := False;
  Current_CH52.Active := False;
  Current_CH53.Active := False;
  Current_CH54.Active := False;
  Current_CH55.Active := False;
  Current_CH56.Active := False;
  Current_CH57.Active := False;
  Current_CH58.Active := False;
  Current_CH59.Active := False;
  Current_CH60.Active := False;
  Current_CH61.Active := False;
  Current_CH62.Active := False;
  Current_CH63.Active := False;
  Current_CH64.Active := False;
end;

procedure TForm1.HorizontalChartLayout_ToolButtonClick(Sender: TObject);
begin
  // 1. 確保 Panel 可見並設定為垂直分割 (一上一下)
  VoltageChart_Panel.Visible := True;
  CurrentChart_Panel.Visible := True;
  VoltageChart_Panel.Align := alTop;
  CurrentChart_Panel.Align := alClient;
  // 2. 隨便亂改一個高寬來觸發Resize
  VoltageChart_Panel.Height:=10;
  VoltageChart_Panel.Width:=10;
end;

procedure TForm1.MainMenu1_1_1Click(Sender: TObject);
var
  temp_str: AnsiString;
begin
  temp_str:='作者: HsiupoYeh.'+#13#10+'程式版本: '+version_str;
  Application.MessageBox(PChar(temp_str),'關於我',64);
end;

procedure TForm1.StatusBar1Resize(Sender: TObject);
var
  temp_remain_width: Integer;
begin
  // --
  // 計算剩餘空間
  temp_remain_width := StatusBar1.Width;

  // --
  // 先配置最後一格（索引4），希望是200
  //
  StatusBar1.Panels.Items[4].Width := 200;
  // 計算剩餘空間
  temp_remain_width := temp_remain_width - StatusBar1.Panels.Items[4].Width;

  // --
  // 配置隔壁一格（索引3），希望是150
  //
  StatusBar1.Panels.Items[3].Width := 150;
  if temp_remain_width < StatusBar1.Panels.Items[3].Width then
  begin
    StatusBar1.Panels.Items[3].Width := temp_remain_width;
  end;
  // 計算剩餘空間
  temp_remain_width := temp_remain_width - StatusBar1.Panels.Items[3].Width;

  // --
  // 配置隔壁一格（索引2），希望是150
  //
  StatusBar1.Panels.Items[2].Width := 150;
  if temp_remain_width < StatusBar1.Panels.Items[2].Width then
  begin
    StatusBar1.Panels.Items[2].Width := temp_remain_width;
  end;
  // 計算剩餘空間
  temp_remain_width := temp_remain_width - StatusBar1.Panels.Items[2].Width;

  // --
  // 配置隔壁一格（索引1），希望是150
  //
  StatusBar1.Panels.Items[1].Width := 150;
  if temp_remain_width < StatusBar1.Panels.Items[1].Width then
  begin
    StatusBar1.Panels.Items[1].Width := temp_remain_width;
  end;
  // 計算剩餘空間
  temp_remain_width := temp_remain_width - StatusBar1.Panels.Items[1].Width;

  // --
  // 最前方一格（索引0）享受最大空間
  //
  StatusBar1.Panels.Items[0].Width := temp_remain_width;

  // --
end;

procedure TForm1.VerticalChartLayout_ToolButtonClick(Sender: TObject);
begin
  // 1. 確保 Panel 可見並設定為水平分割 (一左一右)
  VoltageChart_Panel.Visible := True;
  CurrentChart_Panel.Visible := True;
  VoltageChart_Panel.Align := alLeft;
  CurrentChart_Panel.Align := alClient;
  // 2. 隨便亂改一個高寬來觸發Resize
  VoltageChart_Panel.Height:=10;
  VoltageChart_Panel.Width:=10;
end;

procedure TForm1.VoltageChartOnlyLayout_ToolButtonClick(Sender: TObject);
begin
  CurrentChart_Panel.Align := alNone;
  CurrentChart_Panel.Visible := False;
  VoltageChart_Panel.Align := alClient;
  VoltageChart_Panel.Visible := True;
end;

procedure TForm1.VoltageChart_PanelResize(Sender: TObject);
begin
  // 檢查是否處於垂直分割模式 (ToolButton.Down 狀態)
  if VerticalChartLayout_ToolButton.Down then
  begin
    VoltageChart_Panel.Width := (VoltageChart_Panel.Width + CurrentChart_Panel.Width) div 2;
  end
  // 檢查是否處於水平分割模式
  else if HorizontalChartLayout_ToolButton.Down then
  begin
    VoltageChart_Panel.Height := (VoltageChart_Panel.Height + CurrentChart_Panel.Height) div 2;
  end;
end;

procedure TForm1.Voltage_PopupMenu_1_1Click(Sender: TObject);
begin
  Voltage_PSU.Active := True;
  Voltage_CH01.Active := True;
  Voltage_CH02.Active := True;
  Voltage_CH03.Active := True;
  Voltage_CH04.Active := True;
  Voltage_CH05.Active := True;
  Voltage_CH06.Active := True;
  Voltage_CH07.Active := True;
  Voltage_CH08.Active := True;
  Voltage_CH09.Active := True;
  Voltage_CH10.Active := True;
  Voltage_CH11.Active := True;
  Voltage_CH12.Active := True;
  Voltage_CH13.Active := True;
  Voltage_CH14.Active := True;
  Voltage_CH15.Active := True;
  Voltage_CH16.Active := True;
  Voltage_CH17.Active := True;
  Voltage_CH18.Active := True;
  Voltage_CH19.Active := True;
  Voltage_CH20.Active := True;
  Voltage_CH21.Active := True;
  Voltage_CH22.Active := True;
  Voltage_CH23.Active := True;
  Voltage_CH24.Active := True;
  Voltage_CH25.Active := True;
  Voltage_CH26.Active := True;
  Voltage_CH27.Active := True;
  Voltage_CH28.Active := True;
  Voltage_CH29.Active := True;
  Voltage_CH30.Active := True;
  Voltage_CH31.Active := True;
  Voltage_CH32.Active := True;
  Voltage_CH33.Active := True;
  Voltage_CH34.Active := True;
  Voltage_CH35.Active := True;
  Voltage_CH36.Active := True;
  Voltage_CH37.Active := True;
  Voltage_CH38.Active := True;
  Voltage_CH39.Active := True;
  Voltage_CH40.Active := True;
  Voltage_CH41.Active := True;
  Voltage_CH42.Active := True;
  Voltage_CH43.Active := True;
  Voltage_CH44.Active := True;
  Voltage_CH45.Active := True;
  Voltage_CH46.Active := True;
  Voltage_CH47.Active := True;
  Voltage_CH48.Active := True;
  Voltage_CH49.Active := True;
  Voltage_CH50.Active := True;
  Voltage_CH51.Active := True;
  Voltage_CH52.Active := True;
  Voltage_CH53.Active := True;
  Voltage_CH54.Active := True;
  Voltage_CH55.Active := True;
  Voltage_CH56.Active := True;
  Voltage_CH57.Active := True;
  Voltage_CH58.Active := True;
  Voltage_CH59.Active := True;
  Voltage_CH60.Active := True;
  Voltage_CH61.Active := True;
  Voltage_CH62.Active := True;
  Voltage_CH63.Active := True;
  Voltage_CH64.Active := True;
end;

procedure TForm1.Voltage_PopupMenu_1_2Click(Sender: TObject);
begin
  Voltage_PSU.Active := False;
  Voltage_CH01.Active := False;
  Voltage_CH02.Active := False;
  Voltage_CH03.Active := False;
  Voltage_CH04.Active := False;
  Voltage_CH05.Active := False;
  Voltage_CH06.Active := False;
  Voltage_CH07.Active := False;
  Voltage_CH08.Active := False;
  Voltage_CH09.Active := False;
  Voltage_CH10.Active := False;
  Voltage_CH11.Active := False;
  Voltage_CH12.Active := False;
  Voltage_CH13.Active := False;
  Voltage_CH14.Active := False;
  Voltage_CH15.Active := False;
  Voltage_CH16.Active := False;
  Voltage_CH17.Active := False;
  Voltage_CH18.Active := False;
  Voltage_CH19.Active := False;
  Voltage_CH20.Active := False;
  Voltage_CH21.Active := False;
  Voltage_CH22.Active := False;
  Voltage_CH23.Active := False;
  Voltage_CH24.Active := False;
  Voltage_CH25.Active := False;
  Voltage_CH26.Active := False;
  Voltage_CH27.Active := False;
  Voltage_CH28.Active := False;
  Voltage_CH29.Active := False;
  Voltage_CH30.Active := False;
  Voltage_CH31.Active := False;
  Voltage_CH32.Active := False;
  Voltage_CH33.Active := False;
  Voltage_CH34.Active := False;
  Voltage_CH35.Active := False;
  Voltage_CH36.Active := False;
  Voltage_CH37.Active := False;
  Voltage_CH38.Active := False;
  Voltage_CH39.Active := False;
  Voltage_CH40.Active := False;
  Voltage_CH41.Active := False;
  Voltage_CH42.Active := False;
  Voltage_CH43.Active := False;
  Voltage_CH44.Active := False;
  Voltage_CH45.Active := False;
  Voltage_CH46.Active := False;
  Voltage_CH47.Active := False;
  Voltage_CH48.Active := False;
  Voltage_CH49.Active := False;
  Voltage_CH50.Active := False;
  Voltage_CH51.Active := False;
  Voltage_CH52.Active := False;
  Voltage_CH53.Active := False;
  Voltage_CH54.Active := False;
  Voltage_CH55.Active := False;
  Voltage_CH56.Active := False;
  Voltage_CH57.Active := False;
  Voltage_CH58.Active := False;
  Voltage_CH59.Active := False;
  Voltage_CH60.Active := False;
  Voltage_CH61.Active := False;
  Voltage_CH62.Active := False;
  Voltage_CH63.Active := False;
  Voltage_CH64.Active := False;
end;

end.

