unit Unit1;

{$mode objfpc}{$H+}

interface

uses
  Classes, SysUtils, process, Forms, Controls, Graphics, Dialogs, Menus,
  ComCtrls, ExtCtrls, StdCtrls, AsyncProcess;

type

  { TForm1 }

  TForm1 = class(TForm)
    InversionModeling_AsyncProcess: TAsyncProcess;
    InversionModelingSettingsReadme_GroupBox: TGroupBox;
    InversionModelingSettingsNowJson_GroupBox: TGroupBox;
    InversionModelingSettingsDefaultJson_GroupBox: TGroupBox;
    InversionModelingSettingsCmdLog_GroupBox: TGroupBox;
    InversionModelingOutputSettings_MainName_Edit: TEdit;
    InversionModelingOutputSettings_MainName_GroupBox: TGroupBox;
    InversionModelingOutputSettings_verbose_ComboBox: TComboBox;
    InversionModelingOutputSettings_verbose_GroupBox: TGroupBox;
    InversionModelingOutputSettings_GroupBox: TGroupBox;
    InversionModelingInvSettings_XYMinMax_Edit: TEdit;
    InversionModelingInvSettings_XYMinMax_CheckBox: TCheckBox;
    InversionModelingInvSettings_XYMinMax_GroupBox: TGroupBox;
    InversionModelingInvSettings_ColorBar_Edit: TEdit;
    InversionModelingInvSettings_ColorBar_GroupBox: TGroupBox;
    InversionModelingInvSettings_startModel_Edit: TEdit;
    InversionModelingInvSettings_startModel_GroupBox: TGroupBox;
    InversionModelingInvSettings_RemovePercentage_Edit: TEdit;
    InversionModelingInvSettings_RemovePercentage_GroupBox: TGroupBox;
    InversionModelingInvSettings_RemoveTimes_Edit: TEdit;
    InversionModelingInvSettings_RemoveTimes_GroupBox: TGroupBox;
    InversionModelingInvSettings_limitModelCell_Edit: TEdit;
    InversionModelingInvSettings_limitModelCell_GroupBox: TGroupBox;
    InversionModelingInvSettings_maxIter_Edit: TEdit;
    InversionModelingInvSettings_maxIter_GroupBox: TGroupBox;
    InversionModelingInvSettings_Lambda_Edit: TEdit;
    InversionModelingInvSettings_Lambda_GroupBox: TGroupBox;
    InversionModelingInvSettings_GroupBox: TGroupBox;
    InversionModelingDataPrepare_RemoveBadElectrode_Edit: TEdit;
    InversionModelingDataPrepare_RemoveBadElectrode_CheckBox: TCheckBox;
    InversionModelingDataPrepare_RemoveAppResHigherThan_Edit: TEdit;
    InversionModelingDataPrepare_RemoveAppResHigherThan_GroupBox: TGroupBox;
    InversionModelingDataPrepare_RemoveAppResLowerThan_Edit: TEdit;
    InversionModelingDataPrepare_RemoveAppResLowerThan_GroupBox: TGroupBox;
    InversionModelingDataPrepare_RemoveVoltageHigherThan_Edit: TEdit;
    InversionModelingDataPrepare_RemoveVoltageHigherThan_GroupBox: TGroupBox;
    InversionModelingDataPrepare_RemoveVoltageLowerThan_Edit: TEdit;
    InversionModelingDataPrepare_RemoveVoltageLowerThan_GroupBox: TGroupBox;
    InversionModelingDataPrepare_RemoveCurrentHigherThan_Edit: TEdit;
    InversionModelingDataPrepare_RemoveCurrentHigherThan_GroupBox: TGroupBox;
    InversionModelingDataPrepare_RemoveCurrentLowerThan_Edit: TEdit;
    InversionModelingDataPrepare_RemoveCurrentLowerThan_GroupBox: TGroupBox;
    InversionModelingDataPrepare_UseFakeDataRhoa_Edit: TEdit;
    InversionModelingDataPrepare_UseFakeDataEnable_CheckBox: TCheckBox;
    InversionModelingDataPrepare_GroupBox: TGroupBox;
    InversionModelingDataSettings_paraDX_Edit: TEdit;
    InversionModelingDataSettings_paraDX_GroupBox: TGroupBox;
    InversionModelingDataSettings_addNodes_Edit: TEdit;
    InversionModelingDataSettings_addNodes_GroupBox: TGroupBox;
    InversionModelingDataSettings_paraMaxCellSize_Edit: TEdit;
    InversionModelingDataSettings_paraMaxCellSize_GroupBox: TGroupBox;
    InversionModelingDataSettings_boundary_ComboBox: TComboBox;
    InversionModelingDataSettings_boundary_GroupBox: TGroupBox;
    InversionModelingDataSettings_paraDepth_Edit: TEdit;
    InversionModelingDataSettings_paraDepth_GroupBox: TGroupBox;
    InversionModelingDataSettings_quality_ComboBox: TComboBox;
    InversionModelingDataSettings_quality_GroupBox: TGroupBox;
    InversionModelingDataSettings_ReCalK_ComboBox: TComboBox;
    InversionModelingDataSettings_ReCalK_GroupBox: TGroupBox;
    InversionModelingDataSettings_InvK_ComboBox: TComboBox;
    InversionModelingDataSettings_InvK_GroupBox: TGroupBox;
    InversionModelingDataSettings_RelativeError_Edit: TEdit;
    InversionModelingDataSettings_RelativeError_GroupBox: TGroupBox;
    InversionModelingInvAutoMesh_boundary_ComboBox: TComboBox;
    InversionModelingDataSettings_ReCalMode_ComboBox: TComboBox;
    InversionModelingDataSettings_ReCalMode_GroupBox: TGroupBox;
    InversionModelingDataSettings_GroupBox: TGroupBox;
    InversionModelingInvAutoMesh_paraDX_Edit: TEdit;
    InversionModelingInvAutoMesh_paraDX_GroupBox: TGroupBox;
    InversionModelingInvAutoMesh_addNodes_Edit: TEdit;
    InversionModelingInvAutoMesh_addNodes_GroupBox: TGroupBox;
    InversionModelingInvAutoMesh_paraMaxCellSize_Edit: TEdit;
    InversionModelingInvAutoMesh_paraMaxCellSize_GroupBox: TGroupBox;
    InversionModelingInvAutoMesh_boundary_GroupBox: TGroupBox;
    InversionModelingInvAutoMesh_paraDepth_Edit: TEdit;
    InversionModelingInvAutoMesh_paraDepth_GroupBox: TGroupBox;
    InversionModelingInvAutoMesh_quality_ComboBox: TComboBox;
    InversionModelingInvAutoMesh_quality_GroupBox: TGroupBox;
    InversionModelingInvAutoMesh_Enable_CheckBox: TCheckBox;
    InversionModelingInvAutoMesh_GroupBox: TGroupBox;
    InversionModelingInput03MeshJSON_Edit: TEdit;
    InversionModelingInput03MeshJSON_ManualSelect_Button: TButton;
    InversionModelingInput03MeshJSON_OpenFolder_Button: TButton;
    InversionModelingInput03MeshJSON_GroupBox: TGroupBox;
    InversionModelingInput02VTK_Edit: TEdit;
    InversionModelingInput02VTK_ManualSelect_Button: TButton;
    InversionModelingInput02VTK_OpenFolder_Button: TButton;
    InversionModelingInput02VTK_GroupBox: TGroupBox;
    InversionModelingInput01Ohm_Edit: TEdit;
    InversionModelingInput01Ohm_ManualSelect_Button: TButton;
    InversionModelingInput01Ohm_OpenFolder_Button: TButton;
    InversionModelingInput01Ohm_GroupBox: TGroupBox;
    InversionModelingParameters_GroupBox: TGroupBox;
    Inversion_PageControl: TPageControl;
    InversionModeling_TabSheet: TTabSheet;
    InversionModelingSettings_TabSheet: TTabSheet;
    InversionInputMeshPreview_TabSheet: TTabSheet;
    InversionInputObsDataPreview_TabSheet: TTabSheet;
    InversionResultPreview_TabSheet: TTabSheet;
    InversionAdvancedAnalysisInfo_TabSheet: TTabSheet;
    InversionModelingSettingsCmdLog_Memo: TMemo;
    InversionModelingSettingsDefaultJson_Memo: TMemo;
    InversionModelingSettingsNowJson_Memo: TMemo;
    InversionModelingSettingsReadme_Memo: TMemo;
    TimeSeriesProcessingSelectKeepN_PopupMenu_1_1: TMenuItem;
    TimeSeriesProcessingSelectKeepN_PopupMenu: TPopupMenu;
    TimeSeriesProcessingSelectKeepM_PopupMenu_1_1: TMenuItem;
    TimeSeriesProcessingSelectKeepM_PopupMenu: TPopupMenu;
    TimeSeriesProcessingSelectKeepB_PopupMenu_1_1: TMenuItem;
    TimeSeriesProcessingSelectKeepB_PopupMenu: TPopupMenu;
    TimeSeriesProcessingSelectKeepA_PopupMenu_1_1: TMenuItem;
    OpenDialog1: TOpenDialog;
    TimeSeriesProcessingSelectKeepA_PopupMenu: TPopupMenu;
    TimeSeriesProcessing_AsyncProcess: TAsyncProcess;
    TimeSeriesProcessingSettingsReadme_Memo: TMemo;
    TimeSeriesProcessingSettingsReadme_GroupBox: TGroupBox;
    TimeSeriesProcessingSettingsNowJson_Memo: TMemo;
    TimeSeriesProcessingSettingsNowJson_GroupBox: TGroupBox;
    TimeSeriesProcessingSettingsDefaultJson_Memo: TMemo;
    TimeSeriesProcessingSettingsDefaultJson_GroupBox: TGroupBox;
    TimeSeriesProcessingSettingsCmdLog_Memo: TMemo;
    TimeSeriesProcessingSettingsCmdLog_GroupBox: TGroupBox;
    TimeSeriesProcessingSelectKeepN_Edit: TEdit;
    TimeSeriesProcessingSelectKeepN_GroupBox: TGroupBox;
    TimeSeriesProcessingSelectKeepM_Edit: TEdit;
    TimeSeriesProcessingSelectKeepM_GroupBox: TGroupBox;
    TimeSeriesProcessingSelectKeepB_Edit: TEdit;
    TimeSeriesProcessingSelectKeepB_GroupBox: TGroupBox;
    TimeSeriesProcessingSelectKeepA_Edit: TEdit;
    TimeSeriesProcessingSelectKeepA_GroupBox: TGroupBox;
    TimeSeriesProcessingSelectFrom_GD_RadioButton: TRadioButton;
    TimeSeriesProcessingSelectFrom_MPR_RadioButton: TRadioButton;
    TimeSeriesProcessingSelectFrom_All_RadioButton: TRadioButton;
    TimeSeriesProcessingSelectFrom_MGD_RadioButton: TRadioButton;
    TimeSeriesProcessingSelectFrom_WS_RadioButton: TRadioButton;
    TimeSeriesProcessingSelectFrom_RadioGroup: TRadioGroup;
    TimeSeriesProcessingOutputPNG_Select_CheckBox: TCheckBox;
    TimeSeriesProcessingOutputPNG_GD_CheckBox: TCheckBox;
    TimeSeriesProcessingOutputPNG_MPR_CheckBox: TCheckBox;
    TimeSeriesProcessingOutputPNG_MGD_CheckBox: TCheckBox;
    TimeSeriesProcessingOutputPNG_WS_CheckBox: TCheckBox;
    TimeSeriesProcessingOutputPNG_All_CheckBox: TCheckBox;
    TimeSeriesProcessingOutputPNG_GroupBox: TGroupBox;
    TimeSeriesProcessingInput04ABMN_Edit: TEdit;
    TimeSeriesProcessingInput04ABMN_ManualSelect_Button: TButton;
    TimeSeriesProcessingInput04ABMN_AutoDetect_Button: TButton;
    TimeSeriesProcessingInput04ABMN_OpenFolder_Button: TButton;
    TimeSeriesProcessingInput04ABMN_GroupBox: TGroupBox;
    TimeSeriesProcessingInput03v299Scsv_Edit: TEdit;
    TimeSeriesProcessingInput03v299Scsv_ManualSelect_Button: TButton;
    TimeSeriesProcessingInput03v299Scsv_AutoDetect_Button: TButton;
    TimeSeriesProcessingInput03v299Scsv_OpenFolder_Button: TButton;
    TimeSeriesProcessingInput03v299Scsv_GroupBox: TGroupBox;
    TimeSeriesProcessingInput02Ohm_Edit: TEdit;
    TimeSeriesProcessingInput02Ohm_ManualSelect_Button: TButton;
    TimeSeriesProcessingInput02Ohm_AutoDetect_Button: TButton;
    TimeSeriesProcessingInput02Ohm_OpenFolder_Button: TButton;
    TimeSeriesProcessingInput02Ohm_GroupBox: TGroupBox;
    TimeSeriesProcessingInput01Geo_Edit: TEdit;
    TimeSeriesProcessingInput01Geo_ManualSelect_Button: TButton;
    TimeSeriesProcessingInput01Geo_AutoDetect_Button: TButton;
    TimeSeriesProcessingInput01Geo_OpenFolder_Button: TButton;
    ForwardModeling_AsyncProcess: TAsyncProcess;
    ForwardModelingCurrentMode_ComboBox: TComboBox;
    ForwardModelingCurrentMode_CheckBox: TCheckBox;
    CreateMesh_AsyncProcess: TAsyncProcess;
    ForwardModelingOutputPNGEnable_CheckBox: TCheckBox;
    ForwardModelingElectrodeIndexABResistance_Edit: TEdit;
    ForwardModelingElectrodeIndexABTxCurrentMax_Edit: TEdit;
    ForwardModelingElectrodeIndexABTxVoltageMax_Edit: TEdit;
    CreateMeshLoad_ToolButton: TToolButton;
    CreateMeshOpenOutputFolder_ToolButton: TToolButton;
    CreateMeshParameters_GroupBox: TGroupBox;
    CreateMeshPreview_GroupBox: TGroupBox;
    CreateMeshPreview_Image: TImage;
    CreateMeshRun_ToolButton: TToolButton;
    CreateMesh_ToolBar: TToolBar;
    CreateMeshModelName_GroupBox: TGroupBox;
    CreateMeshModelName_Edit: TEdit;
    CreateMeshColorbarMinMax_GroupBox: TGroupBox;
    CreateMeshColorbarMinMax_Edit: TEdit;
    CreateMeshStudyAreaMeshLayerSettings_GroupBox: TGroupBox;
    CreateMeshStudyAreaMeshLayerSettings_Edit: TEdit;
    CreateMeshPaddingMeshLeftSettings_GroupBox: TGroupBox;
    CreateMeshPaddingMeshLeftSettings_Edit: TEdit;
    CreateMeshPaddingMeshRightSettings_GroupBox: TGroupBox;
    CreateMeshPaddingMeshRightSettings_Edit: TEdit;
    CreateMeshPaddingMeshBottomSettings_GroupBox: TGroupBox;
    CreateMeshPaddingMeshBottomSettings_Edit: TEdit;
    CreateMeshSurfaceNodeSettings_GroupBox: TGroupBox;
    CreateMeshModifyMeshResistivitySettings_GroupBox: TGroupBox;
    CreateMeshSettingsCmdLog_GroupBox: TGroupBox;
    CreateMeshSettingsDefaultJson_GroupBox: TGroupBox;
    CreateMeshSettingsNowJson_GroupBox: TGroupBox;
    CreateMeshSettingsReadme_GroupBox: TGroupBox;
    ForwardModelingParameters_GroupBox: TGroupBox;
    ForwardModelingPreview_GroupBox: TGroupBox;
    ForwardModelingPreview_Image: TImage;
    ForwardModelingElectrodeIndexABTxVoltageMax_GroupBox: TGroupBox;
    ForwardModelingElectrodeIndexABTxCurrentMax_GroupBox: TGroupBox;
    ForwardModelingElectrodeIndexABResistance_GroupBox: TGroupBox;
    ForwardModelingRuntimeEnvironmentDescription_GroupBox: TGroupBox;
    ForwardModelingSettingsCmdLog_GroupBox: TGroupBox;
    ForwardModelingSettingsDefaultJson_GroupBox: TGroupBox;
    ForwardModelingSettingsNowJson_GroupBox: TGroupBox;
    ForwardModelingSettingsReadme_GroupBox: TGroupBox;
    ForwardModelingCurrentMode_GroupBox: TGroupBox;
    TimeSeriesProcessingInput01Geo_GroupBox: TGroupBox;
    TimeSeriesProcessingParameters_GroupBox: TGroupBox;
    MainMenu1: TMainMenu;
    MainMenu1_1: TMenuItem;
    MainMenu1_1_1: TMenuItem;
    EmptyPanel: TPanel;
    Main_PageControl: TPageControl;
    Forward_PageControl: TPageControl;
    CreateMeshSurfaceNodeSettings_Memo: TMemo;
    CreateMeshModifyMeshResistivitySettings_Memo: TMemo;
    CreateMeshSettingsCmdLog_Memo: TMemo;
    CreateMeshSettingsDefaultJson_Memo: TMemo;
    CreateMeshSettingsNowJson_Memo: TMemo;
    CreateMeshSettingsReadme_Memo: TMemo;
    ForwardModelingRuntimeEnvironmentDescription_Memo: TMemo;
    ForwardModelingSettingsCmdLog_Memo: TMemo;
    ForwardModelingSettingsDefaultJson_Memo: TMemo;
    ForwardModelingSettingsNowJson_Memo: TMemo;
    ForwardModelingSettingsReadme_Memo: TMemo;
    Process1: TProcess;
    ForwardModeling_Timer: TTimer;
    TimeSeriesProcessing_ToolBar: TToolBar;
    TimeSeriesProcessingRun_ToolButton: TToolButton;
    TimeSeriesProcessingOpenOutputFolder_ToolButton: TToolButton;
    InversionModeling_ToolBar: TToolBar;
    InversionModelingRun_ToolButton: TToolButton;
    InversionModelingOpenOutputFolder_ToolButton: TToolButton;
    UpdateLog_Memo: TMemo;
    RunningLog_Memo: TMemo;
    ScrollBox1: TScrollBox;
    StatusBar1: TStatusBar;
    Forward_TabSheet: TTabSheet;
    Inversion_TabSheet: TTabSheet;
    RunningLog_TabSheet: TTabSheet;
    CreateMesh_TabSheet: TTabSheet;
    CreateMeshSettings_TabSheet: TTabSheet;
    ForwardModeling_TabSheet: TTabSheet;
    ForwardModelingSettings_TabSheet: TTabSheet;
    TimeSeriesProcessingSettings_TabSheet: TTabSheet;
    TimeSeriesProcessing_TabSheet: TTabSheet;
    ForwardModeling_ToolBar: TToolBar;
    ForwardModelingRun_ToolButton: TToolButton;
    ForwardModelingOpenOutputFolder_ToolButton: TToolButton;
    UpdateLog_TabSheet: TTabSheet;
    procedure CreateMeshLoad_ToolButtonClick(Sender: TObject);
    procedure CreateMeshOpenOutputFolder_ToolButtonClick(Sender: TObject);
    procedure CreateMeshRun_ToolButtonClick(Sender: TObject);
    procedure CreateMesh_AsyncProcessReadData(Sender: TObject);
    procedure CreateMesh_AsyncProcessTerminate(Sender: TObject);
    procedure FormCreate(Sender: TObject);
    procedure FormResize(Sender: TObject);
    procedure FormShow(Sender: TObject);
    procedure ForwardModelingCurrentMode_CheckBoxClick(Sender: TObject);
    procedure ForwardModelingOpenOutputFolder_ToolButtonClick(Sender: TObject);
    procedure ForwardModelingRun_ToolButtonClick(Sender: TObject);
    procedure ForwardModeling_AsyncProcessReadData(Sender: TObject);
    procedure ForwardModeling_AsyncProcessTerminate(Sender: TObject);
    procedure ForwardModeling_TimerTimer(Sender: TObject);
    procedure InversionModelingDataPrepare_RemoveBadElectrode_CheckBoxChange(
      Sender: TObject);
    procedure InversionModelingDataPrepare_UseFakeDataEnable_CheckBoxChange(
      Sender: TObject);
    procedure InversionModelingDataSettings_GroupBoxClick(Sender: TObject);
    procedure InversionModelingDataSettings_ReCalK_ComboBoxChange(
      Sender: TObject);
    procedure InversionModelingInput01Ohm_ManualSelect_ButtonClick(
      Sender: TObject);
    procedure InversionModelingInput01Ohm_OpenFolder_ButtonClick(Sender: TObject
      );
    procedure InversionModelingInput02VTK_ManualSelect_ButtonClick(
      Sender: TObject);
    procedure InversionModelingInput02VTK_OpenFolder_ButtonClick(Sender: TObject
      );
    procedure InversionModelingInput03MeshJSON_ManualSelect_ButtonClick(
      Sender: TObject);
    procedure InversionModelingInput03MeshJSON_OpenFolder_ButtonClick(
      Sender: TObject);
    procedure InversionModelingInvAutoMesh_Enable_CheckBoxChange(Sender: TObject
      );
    procedure InversionModelingInvSettings_XYMinMax_CheckBoxChange(
      Sender: TObject);
    procedure InversionModelingOpenOutputFolder_ToolButtonClick(Sender: TObject
      );
    procedure InversionModelingRun_ToolButtonClick(Sender: TObject);
    procedure InversionModeling_AsyncProcessReadData(Sender: TObject);
    procedure InversionModeling_AsyncProcessTerminate(Sender: TObject);
    procedure MainMenu1_1_1Click(Sender: TObject);
    procedure StatusBar1Resize(Sender: TObject);
    procedure TimeSeriesProcessingInput01Geo_AutoDetect_ButtonClick(
      Sender: TObject);
    procedure TimeSeriesProcessingInput01Geo_ManualSelect_ButtonClick(
      Sender: TObject);
    procedure TimeSeriesProcessingInput01Geo_OpenFolder_ButtonClick(
      Sender: TObject);
    procedure TimeSeriesProcessingInput02Ohm_AutoDetect_ButtonClick(
      Sender: TObject);
    procedure TimeSeriesProcessingInput02Ohm_ManualSelect_ButtonClick(
      Sender: TObject);
    procedure TimeSeriesProcessingInput02Ohm_OpenFolder_ButtonClick(
      Sender: TObject);
    procedure TimeSeriesProcessingInput03v299Scsv_AutoDetect_ButtonClick(
      Sender: TObject);
    procedure TimeSeriesProcessingInput03v299Scsv_ManualSelect_ButtonClick(
      Sender: TObject);
    procedure TimeSeriesProcessingInput03v299Scsv_OpenFolder_ButtonClick(
      Sender: TObject);
    procedure TimeSeriesProcessingInput04ABMN_AutoDetect_ButtonClick(
      Sender: TObject);
    procedure TimeSeriesProcessingInput04ABMN_ManualSelect_ButtonClick(
      Sender: TObject);
    procedure TimeSeriesProcessingInput04ABMN_OpenFolder_ButtonClick(
      Sender: TObject);
    procedure TimeSeriesProcessingOpenOutputFolder_ToolButtonClick(
      Sender: TObject);
    procedure TimeSeriesProcessingRun_ToolButtonClick(Sender: TObject);
    procedure TimeSeriesProcessingSelectKeepA_PopupMenu_1_1Click(Sender: TObject
      );
    procedure TimeSeriesProcessingSelectKeepB_PopupMenu_1_1Click(Sender: TObject
      );
    procedure TimeSeriesProcessingSelectKeepM_PopupMenu_1_1Click(Sender: TObject
      );
    procedure TimeSeriesProcessingSelectKeepN_PopupMenu_1_1Click(Sender: TObject
      );
    procedure TimeSeriesProcessing_AsyncProcessReadData(Sender: TObject);
    procedure TimeSeriesProcessing_AsyncProcessTerminate(Sender: TObject);
  private

  public

  end;

var
  Form1: TForm1;

implementation
uses
  RegExpr, LazUTF8, Windows, ShellApi, FileUtil;
//--------------------------------------------------------------------------
//宣告全域變數 add by HsiupoYeh
var
  version_str: AnsiString;
  Current_Folder_Path: AnsiString;
  Form1CreateMeshPreview_ImageWidthDiffPx: Integer;
  Form1CreateMeshPreview_ImageHeightDiffPx: Integer;
  Form1ForwardModelingPreview_ImageWidthDiffPx: Integer;
  Form1ForwardModelingPreview_ImageHeightDiffPx: Integer;
//--------------------------------------------------------------------------

{$R *.lfm}

{ TForm1 }

procedure TForm1.FormCreate(Sender: TObject);
begin
  //--------------------------------------------------------------------------
  // 在這裡對全域變數進行初始化
  version_str := 'v1.0(v20260410a)';
  Current_Folder_Path := ExtractFilePath(Application.ExeName);
  //--------------------------------------------------------------------------
  //--------------------------------------------------------------------------
  // 表單標題追加版本
  Form1.Caption := Form1.Caption + ' ' + version_str;
  //--------------------------------------------------------------------------
end;

procedure TForm1.CreateMeshLoad_ToolButtonClick(Sender: TObject);
begin

end;

procedure TForm1.CreateMeshOpenOutputFolder_ToolButtonClick(Sender: TObject);
var
  temp_str: string;
begin
  // 取得資料夾路徑
  temp_str:=CreateMeshSettingsDefaultJson_Memo.Lines.Strings[41-1];
  temp_str:=StringReplace(temp_str, '"OutputFile06_BasicMeshPNG_FileName":"', '', [rfReplaceAll]);
  temp_str:=StringReplace(temp_str, '",', '', [rfReplaceAll]);
  temp_str:=ExtractFilePath(Application.ExeName)+temp_str;
  temp_str:=ExtractFilePath(temp_str);
  ForceDirectories(temp_str);
  // 記得在 uses 區塊中加入 Windows, ShellApi
  // 使用 ShellExecute 打開該資料夾
  //ShellExecute(0, 'open', PChar(temp_str), nil, nil, SW_SHOWNORMAL);//這個不支援中文，改用ShellExecuteW
  ShellExecuteW(0, 'open', PWideChar(UTF8ToUTF16(temp_str)), nil, nil, SW_SHOWNORMAL);
end;

procedure TForm1.CreateMeshRun_ToolButtonClick(Sender: TObject);
var
  temp_i: Integer;
  RegexObj: TRegExpr;
  temp_str: AnsiString;
  temp_StartTime: DWord;
begin
  CreateMeshSettingsNowJson_Memo.Clear;
  CreateMeshPreview_Image.Picture.Clear;
  StatusBar1.Panels[0].Text:='建立模型網格...請稍後!';
  //--------------------------------------------------------------------------
  //
  for temp_i := 0 to 64-1 do
  begin
    CreateMeshSettingsNowJson_Memo.Lines.Add(CreateMeshSettingsDefaultJson_Memo.Lines.Strings[temp_i]);
  end;
  //--------------------------------------------------------------------------
  //--
  // 刪除圖片
  temp_str:=CreateMeshSettingsNowJson_Memo.Lines.Strings[41-1];
  temp_str:=StringReplace(temp_str, '"OutputFile06_BasicMeshPNG_FileName":"', '', [rfReplaceAll]);
  temp_str:=StringReplace(temp_str, '",', '', [rfReplaceAll]);
  if FileExists(temp_str) then
  begin
    DeleteFile(PChar(temp_str));
    StatusBar1.Panels[0].Text:='建立模型網格...已刪除舊的預覽圖片，請稍後!';
  end;
  //--
  RegexObj := TRegExpr.Create;
  try
    //--------------------------------------------------------------------------
    // CreateMeshModelName_Edit
    RegexObj.Expression := '[<>:"/\\|?*]';
    if RegexObj.Exec(CreateMeshModelName_Edit.Text) then
    begin
      // --- 發現非法字元 ---
      temp_str := '錯誤:' + #13#10 +
        '模型名稱為不接受的字元。' + #13#10 +
        '不可使用以下字元: <>:"/\\|?*';
      Application.MessageBox(PChar(temp_str), '錯誤', 16);
      Exit;
    end;
    CreateMeshSettingsNowJson_Memo.Lines.Strings[31-1] := ('"OutputFile01_MeshBCMarkersJSON_FileName":"Output_ERTMaker_CreateAndModifyMesh/'+CreateMeshModelName_Edit.Text+'_SyntheticModelBCMarkers.json",');
    CreateMeshSettingsNowJson_Memo.Lines.Strings[33-1] := ('"OutputFile02_MeshBCMarkersVTK_FileName":"Output_ERTMaker_CreateAndModifyMesh/'+CreateMeshModelName_Edit.Text+'_SyntheticModel.vtk",');
    CreateMeshSettingsNowJson_Memo.Lines.Strings[35-1] := ('"OutputFile03_GEO_FileName":"Output_ERTMaker_CreateAndModifyMesh/'+CreateMeshModelName_Edit.Text+'_SyntheticModel.geo",');
    CreateMeshSettingsNowJson_Memo.Lines.Strings[37-1] := ('"OutputFile04_TRN_FileName":"Output_ERTMaker_CreateAndModifyMesh/'+CreateMeshModelName_Edit.Text+'_SyntheticModel.trn",');
    CreateMeshSettingsNowJson_Memo.Lines.Strings[39-1] := ('"OutputFile05_OHM_FileName":"Output_ERTMaker_CreateAndModifyMesh/'+CreateMeshModelName_Edit.Text+'_SyntheticModel.ohm",');
    CreateMeshSettingsNowJson_Memo.Lines.Strings[41-1] := ('"OutputFile06_BasicMeshPNG_FileName":"Output_ERTMaker_CreateAndModifyMesh/'+CreateMeshModelName_Edit.Text+'_SyntheticModel.png",');
    CreateMeshSettingsNowJson_Memo.Lines.Strings[49-1] := ('"OutputFile06_BasicMeshPNG_Title":"'+CreateMeshModelName_Edit.Text+' Synthetic Model",');
    //--------------------------------------------------------------------------
    //--------------------------------------------------------------------------
    // CreateMeshColorbarMinMax_Edit
    RegexObj.Expression := '^\s*([-+]?(\d+\.?\d*|\.\d+))\s*,\s*([-+]?(\d+\.?\d*|\.\d+))\s*$';
    if not RegexObj.Exec(CreateMeshColorbarMinMax_Edit.Text) then
    begin
      // 錯誤的資料內容
      temp_str := '錯誤:' + #13#10 +
        '電阻率色階數值錯誤。請檢查。';
      Application.MessageBox(PChar(temp_str), '錯誤', 16);
      Exit;
    end;
    if StrToFloat(RegexObj.Match[1]) >= StrToFloat(RegexObj.Match[3]) then
    begin
      temp_str := '錯誤:' + #13#10 +
        '電阻率色階最小值必須小於最大值。';
      Application.MessageBox(PChar(temp_str), '錯誤', 16);
      Exit;
    end;
    CreateMeshSettingsNowJson_Memo.Lines.Strings[51-1] := ('"OutputFile06_BasicMeshPNG_ColorBarResistivityMin":'+RegexObj.Match[1]+',');
    CreateMeshSettingsNowJson_Memo.Lines.Strings[53-1] := ('"OutputFile06_BasicMeshPNG_ColorBarResistivityMax":'+RegexObj.Match[3]+',');
    //--------------------------------------------------------------------------
    //--------------------------------------------------------------------------
    // CreateMeshStudyAreaMeshLayerSettings_Edit
    RegexObj.Expression := '^\s*(\d+)\s*,\s*(\d*\.?\d+)\s*,\s*(\d*\.?\d+)\s*$';
    if not RegexObj.Exec(CreateMeshStudyAreaMeshLayerSettings_Edit.Text) then
    begin
      // 錯誤的資料內容
      temp_str := '錯誤:' + #13#10 +
        '研究區域內網格設定(地層數,厚度因子,首層厚度)值錯誤。請檢查。';
      Application.MessageBox(PChar(temp_str), '錯誤', 16);
      Exit;
    end;
    if StrToFloat(RegexObj.Match[1]) <= 0 then
    begin
      temp_str := '錯誤:' + #13#10 +
        '研究區域內網格設定(地層數,厚度因子,首層厚度)值第1個數字必須為正整數。';
      Application.MessageBox(PChar(temp_str), '錯誤', 16);
      Exit;
    end;
    if StrToFloat(RegexObj.Match[2]) <= 0 then
    begin
      temp_str := '錯誤:' + #13#10 +
        '研究區域內網格設定(地層數,厚度因子,首層厚度)值第2個數字必須為正數。';
      Application.MessageBox(PChar(temp_str), '錯誤', 16);
      Exit;
    end;
    if StrToFloat(RegexObj.Match[3]) <= 0 then
    begin
      temp_str := '錯誤:' + #13#10 +
        '研究區域內網格設定(地層數,厚度因子,首層厚度)值第3個數字必須為正數。';
      Application.MessageBox(PChar(temp_str), '錯誤', 16);
      Exit;
    end;
    CreateMeshSettingsNowJson_Memo.Lines.Strings[57-1] := ('"StudyAreaMesh_RectangleGrid_LayerCount":'+RegexObj.Match[1]+',');
    CreateMeshSettingsNowJson_Memo.Lines.Strings[59-1] := ('"StudyAreaMesh_RectangleGrid_LayerThicknessFacfor":'+RegexObj.Match[2]+',');
    CreateMeshSettingsNowJson_Memo.Lines.Strings[61-1] := ('"StudyAreaMesh_RectangleGrid_FirstLayerThickness":'+RegexObj.Match[3]+',');
    //--------------------------------------------------------------------------
    //--------------------------------------------------------------------------
    // CreateMeshSurfaceNodeSettings_Memo
    RegexObj.Expression := '^\s*([-+]?(\d+\.?\d*|\.\d+))\s*,\s*(null|([-+]?(\d+\.?\d*|\.\d+)))\s*,\s*(\d+)\s*$';
    for temp_i := 0 to CreateMeshSurfaceNodeSettings_Memo.Lines.Count-1 do
    begin
      //--
      if Trim(CreateMeshSurfaceNodeSettings_Memo.Lines.Strings[temp_i]) = '' then
      begin
        // 錯誤的資料內容
        temp_str := '錯誤:' + #13#10 +
          '地表節點(X,Z,電極索引)值不允許有空白行。請檢查。';
        Application.MessageBox(PChar(temp_str), '錯誤', 16);
        Exit;
      end;
      //--
      if not RegexObj.Exec(CreateMeshSurfaceNodeSettings_Memo.Lines.Strings[temp_i]) then
      begin
        // 錯誤的資料內容
        temp_str := '錯誤:' + #13#10 +
          '地表節點(X,Z,電極索引)值錯誤。請檢查。';
        Application.MessageBox(PChar(temp_str), '錯誤', 16);
        Exit;
      end;
      if temp_i = CreateMeshSurfaceNodeSettings_Memo.Lines.Count-1 then
      begin
        CreateMeshSettingsNowJson_Memo.Lines.Add('['+Trim(CreateMeshSurfaceNodeSettings_Memo.Lines.Strings[temp_i])+']');
      end
      else
      begin
        CreateMeshSettingsNowJson_Memo.Lines.Add('['+Trim(CreateMeshSurfaceNodeSettings_Memo.Lines.Strings[temp_i])+'],');
      end;
      //--
    end;
    CreateMeshSettingsNowJson_Memo.Lines.Add('],');
    //--------------------------------------------------------------------------
    //--------------------------------------------------------------------------
    // CreateMeshPaddingMeshLeftSettings_Edit
    RegexObj.Expression := '^\s*(\d+)\s*,\s*(\d*\.?\d+)\s*,\s*([-+]?(\d+\.?\d*|\.\d+))\s*$';
    if not RegexObj.Exec(CreateMeshPaddingMeshLeftSettings_Edit.Text) then
    begin
      // 錯誤的資料內容
      temp_str := '錯誤:' + #13#10 +
        '附加區域左側網格設定(層數,寬度因子,首層寬度)值錯誤。請檢查。';
      Application.MessageBox(PChar(temp_str), '錯誤', 16);
      Exit;
    end;
    if StrToFloat(RegexObj.Match[1]) <= 0 then
    begin
      temp_str := '錯誤:' + #13#10 +
        '附加區域左側網格設定(層數,寬度因子,首層寬度)值第1個數字必須為正整數。';
      Application.MessageBox(PChar(temp_str), '錯誤', 16);
      Exit;
    end;
    if StrToFloat(RegexObj.Match[2]) <= 0 then
    begin
      temp_str := '錯誤:' + #13#10 +
        '附加區域左側網格設定(層數,寬度因子,首層寬度)值第2個數字必須為正數。';
      Application.MessageBox(PChar(temp_str), '錯誤', 16);
      Exit;
    end;
    CreateMeshSettingsNowJson_Memo.Lines.Add('"PaddingMesh_GridStyle_Readme":"附加區域的網格類型。目前只支援「Rectangle」，就是指以矩形為基礎的網格類型。",');
    CreateMeshSettingsNowJson_Memo.Lines.Add('"PaddingMesh_GridStyle":"Rectangle",');
    CreateMeshSettingsNowJson_Memo.Lines.Add('"PaddingMesh_RectangleGrid_LeftPaddingLayerCount_Readme":"附加區域左側要追加的網格層數。就是指-X方向追加的地層數量。此值必須是0或是正整數。",');
    CreateMeshSettingsNowJson_Memo.Lines.Add('"PaddingMesh_RectangleGrid_LeftPaddingLayerCount":'+RegexObj.Match[1]+',');
    CreateMeshSettingsNowJson_Memo.Lines.Add('"PaddingMesh_RectangleGrid_LeftPaddingLayerWidthFacfor_Readme":"附加區域左側的地層寬度控制因子。此值必須是正數。1表示寬度不變化，0.9表示寬度變小為原本的90%，1.1表示寬度變大為原本的110%。",');
    CreateMeshSettingsNowJson_Memo.Lines.Add('"PaddingMesh_RectangleGrid_LeftPaddingLayerWidthFacfor":'+RegexObj.Match[2]+',');
    CreateMeshSettingsNowJson_Memo.Lines.Add('"PaddingMesh_RectangleGrid_FirstLeftPaddingLayerWidth_Readme":"附加區域左側的第一層寬度。單位:[m]。此值小於等於0的時候，表示自動使用最靠近的一層搭配厚度因子計算出第一層寬度，否則直接使用指定數值為第一層寬度。",');
    CreateMeshSettingsNowJson_Memo.Lines.Add('"PaddingMesh_RectangleGrid_FirstLeftPaddingLayerWidth":'+RegexObj.Match[3]+',');
    //--------------------------------------------------------------------------
    //--------------------------------------------------------------------------
    // CreateMeshPaddingMeshRightSettings_Edit
    RegexObj.Expression := '^\s*(\d+)\s*,\s*(\d*\.?\d+)\s*,\s*([-+]?(\d+\.?\d*|\.\d+))\s*$';
    if not RegexObj.Exec(CreateMeshPaddingMeshRightSettings_Edit.Text) then
    begin
      // 錯誤的資料內容
      temp_str := '錯誤:' + #13#10 +
        '附加區域右側網格設定(層數,寬度因子,首層寬度)值錯誤。請檢查。';
      Application.MessageBox(PChar(temp_str), '錯誤', 16);
      Exit;
    end;
    if StrToFloat(RegexObj.Match[1]) <= 0 then
    begin
      temp_str := '錯誤:' + #13#10 +
        '附加區域右側網格設定(層數,寬度因子,首層寬度)值第1個數字必須為正整數。';
      Application.MessageBox(PChar(temp_str), '錯誤', 16);
      Exit;
    end;
    if StrToFloat(RegexObj.Match[2]) <= 0 then
    begin
      temp_str := '錯誤:' + #13#10 +
        '附加區域右側網格設定(層數,寬度因子,首層寬度)值第2個數字必須為正數。';
      Application.MessageBox(PChar(temp_str), '錯誤', 16);
      Exit;
    end;
    CreateMeshSettingsNowJson_Memo.Lines.Add('"PaddingMesh_RectangleGrid_RightPaddingLayerCount_Readme":"附加區域右側要追加的網格層數。就是指+X方向追加的地層數量。此值必須是0或是正整數。",');
    CreateMeshSettingsNowJson_Memo.Lines.Add('"PaddingMesh_RectangleGrid_RightPaddingLayerCount":'+RegexObj.Match[1]+',');
    CreateMeshSettingsNowJson_Memo.Lines.Add('"PaddingMesh_RectangleGrid_RightPaddingLayerWidthFacfor_Readme":"附加區域右側的地層寬度控制因子。此值必須是正數。1表示寬度不變化，0.9表示寬度變小為原本的90%，1.1表示寬度變大為原本的110%。",');
    CreateMeshSettingsNowJson_Memo.Lines.Add('"PaddingMesh_RectangleGrid_RightPaddingLayerWidthFacfor":'+RegexObj.Match[2]+',');
    CreateMeshSettingsNowJson_Memo.Lines.Add('"PaddingMesh_RectangleGrid_FirstRightPaddingLayerWidth_Readme":"附加區域右側的第一層寬度。單位:[m]。此值小於等於0的時候，表示自動使用最靠近的一層搭配厚度因子計算出第一層寬度，否則直接使用指定數值為第一層寬度。",');
    CreateMeshSettingsNowJson_Memo.Lines.Add('"PaddingMesh_RectangleGrid_FirstRightPaddingLayerWidth":'+RegexObj.Match[3]+',');
    //--------------------------------------------------------------------------
    //--------------------------------------------------------------------------
    // CreateMeshPaddingMeshBottomSettings_Edit
    RegexObj.Expression := '^\s*(\d+)\s*,\s*(\d*\.?\d+)\s*,\s*([-+]?(\d+\.?\d*|\.\d+))\s*$';
    if not RegexObj.Exec(CreateMeshPaddingMeshBottomSettings_Edit.Text) then
    begin
      // 錯誤的資料內容
      temp_str := '錯誤:' + #13#10 +
        '附加區域下方網格設定(層數,寬度因子,首層寬度)值錯誤。請檢查。';
      Application.MessageBox(PChar(temp_str), '錯誤', 16);
      Exit;
    end;
    if StrToFloat(RegexObj.Match[1]) <= 0 then
    begin
      temp_str := '錯誤:' + #13#10 +
        '附加區域下方網格設定(層數,寬度因子,首層寬度)值第1個數字必須為正整數。';
      Application.MessageBox(PChar(temp_str), '錯誤', 16);
      Exit;
    end;
    if StrToFloat(RegexObj.Match[2]) <= 0 then
    begin
      temp_str := '錯誤:' + #13#10 +
        '附加區域下方網格設定(層數,寬度因子,首層寬度)值第2個數字必須為正數。';
      Application.MessageBox(PChar(temp_str), '錯誤', 16);
      Exit;
    end;
    CreateMeshSettingsNowJson_Memo.Lines.Add('"PaddingMesh_RectangleGrid_BottomPaddingLayerCount_Readme":"附加區域下方的網格層數。是指Z方向的地層數量。此值必須是0或正整數。",');
    CreateMeshSettingsNowJson_Memo.Lines.Add('"PaddingMesh_RectangleGrid_BottomPaddingLayerCount":'+RegexObj.Match[1]+',');
    CreateMeshSettingsNowJson_Memo.Lines.Add('"PaddingMesh_RectangleGrid_BottomPaddingLayerThicknessFacfor_Readme":"附加區域右側的地層寬度控制因子。此值必須是正數。1表示寬度不變化，0.9表示寬度變小為原本的90%，1.1表示寬度變大為原本的110%。",');
    CreateMeshSettingsNowJson_Memo.Lines.Add('"PaddingMesh_RectangleGrid_BottomPaddingLayerThicknessFacfor":'+RegexObj.Match[2]+',');
    CreateMeshSettingsNowJson_Memo.Lines.Add('"PaddingMesh_RectangleGrid_FirstBottomPaddingLayerThickness_Readme":"附加區域的第一層厚度。單位:[m]。此值小於等於0的時候，表示自動使用最靠近的一層搭配厚度因子計算出第一層厚度，否則直接使用指定數值為第一層厚度。",');
    CreateMeshSettingsNowJson_Memo.Lines.Add('"PaddingMesh_RectangleGrid_FirstBottomPaddingLayerThickness":'+RegexObj.Match[3]+',');
    //--------------------------------------------------------------------------
    //--------------------------------------------------------------------------
    // CreateMeshModifyMeshResistivitySettings_Memo
    CreateMeshSettingsNowJson_Memo.Lines.Add('"ModifyMeshResistivity_Readme":"依序填入多則修改範圍，將依照規則順序修改模型。",');
    CreateMeshSettingsNowJson_Memo.Lines.Add('"ModifyMeshResistivity_Readme2":"x_min[m],x_max[m],z_min[m],z_max[m],New_Resistivity[ohm-m]",');
    CreateMeshSettingsNowJson_Memo.Lines.Add('"ModifyMeshResistivity":[');
    RegexObj.Expression := '^\s*([-+]?(\d+\.?\d*|\.\d+))\s*,\s*([-+]?(\d+\.?\d*|\.\d+))\s*,\s*([-+]?(\d+\.?\d*|\.\d+))\s*,\s*([-+]?(\d+\.?\d*|\.\d+))\s*,\s*(\d*\.?\d+)\s*$';
    for temp_i := 0 to CreateMeshModifyMeshResistivitySettings_Memo.Lines.Count-1 do
    begin
      //--
      if Trim(CreateMeshModifyMeshResistivitySettings_Memo.Lines.Strings[temp_i]) = '' then
      begin
        // 錯誤的資料內容
        temp_str := '錯誤:' + #13#10 +
          '電阻率規則(xmin,xmax,zmin,zmax,newRes)值不允許有空白行。請檢查。';
        Application.MessageBox(PChar(temp_str), '錯誤', 16);
        Exit;
      end;
      //--
      if not RegexObj.Exec(CreateMeshModifyMeshResistivitySettings_Memo.Lines.Strings[temp_i]) then
      begin
        // 錯誤的資料內容
        temp_str := '錯誤:' + #13#10 +
          '電阻率規則(xmin,xmax,zmin,zmax,newRes):值錯誤。請檢查。';
        Application.MessageBox(PChar(temp_str), '錯誤', 16);
        Exit;
      end;
      if temp_i = CreateMeshModifyMeshResistivitySettings_Memo.Lines.Count-1 then
      begin
        CreateMeshSettingsNowJson_Memo.Lines.Add('['+Trim(CreateMeshModifyMeshResistivitySettings_Memo.Lines.Strings[temp_i])+']');
      end
      else
      begin
        CreateMeshSettingsNowJson_Memo.Lines.Add('['+Trim(CreateMeshModifyMeshResistivitySettings_Memo.Lines.Strings[temp_i])+'],');
      end;
      //--
    end;
    CreateMeshSettingsNowJson_Memo.Lines.Add(']');
    CreateMeshSettingsNowJson_Memo.Lines.Add('}');
    //--------------------------------------------------------------------------
    // 儲存預設JSON檔案
    ForceDirectories('Input_ERTMaker_CreateAndModifyMesh');
    CreateMeshSettingsNowJson_Memo.Lines.SaveToFile('Input_ERTMaker_CreateAndModifyMesh/CreateAndModifyMeshSettings.json',TEncoding.UTF8);
    //--------------------------------------------------------------------------
    //--------------------------------------------------------------------------
    // 等待1秒，讓刪除檔案有時間完成
    temp_StartTime := GetTickCount; // 獲取當前系統時間(ms)
    while(GetTickCount() - temp_StartTime < 1000*1) do//1000*1=等1秒
    begin
      Application.ProcessMessages;
      Sleep(1);//休眠1msend;
    end;
    //--------------------------------------------------------------------------
    //--------------------------------------------------------------------------
    // 外部Python程式檢查
    if not FileExists('PythonEnv\Python.exe') then
    begin
      temp_str := '錯誤:' + #13#10 +
        '外部Python環境不存在。';
      Application.MessageBox(PChar(temp_str), '錯誤', 16);
      Exit;
    end;
    if not FileExists('ERTMaker_CreateAndModifyMesh_v20260112a.cpython-312.pyc') then
    begin
      temp_str := '錯誤:' + #13#10 +
        '外部Python程式不存在。';
      Application.MessageBox(PChar(temp_str), '錯誤', 16);
      Exit;
    end;
    //--------------------------------------------------------------------------
    //--------------------------------------------------------------------------
    CreateMeshSettingsCmdLog_Memo.Lines.Clear;
    // 使用 CreateMesh_AsyncProcess 運行外部程式
    CreateMesh_AsyncProcess.Executable:='cmd.exe';
    CreateMesh_AsyncProcess.Parameters.Clear;
    CreateMesh_AsyncProcess.Parameters.Add('/c');
    CreateMesh_AsyncProcess.Parameters.Add('.\PythonEnv\Python.exe -u ERTMaker_CreateAndModifyMesh_v20260112a.cpython-312.pyc');
    CreateMesh_AsyncProcess.Options:=[poUsePipes] + [poNoConsole];
    CreateMesh_AsyncProcess.Execute;
    // 禁用元件，等背景運作完再從事件重新啟用按鈕
    CreateMeshRun_ToolButton.Enabled:=False;
    CreateMeshParameters_GroupBox.Enabled:=False;
    ForwardModelingParameters_GroupBox.Enabled:=False;
    //--------------------------------------------------------------------------
  finally
    RegexObj.Free; // 釋放 TRegExpr 物件
  end;
  //--------------------------------------------------------------------------
end;

procedure TForm1.CreateMesh_AsyncProcessReadData(Sender: TObject);
var
  temp_Buffer:string='';
  temp_BytesAvailable:DWord;
begin
  //--------------------------------------------------------------------------
  // 顯示外部cmd.exe運行內容
  temp_BytesAvailable:=CreateMesh_AsyncProcess.Output.NumBytesAvailable;
  if temp_BytesAvailable>0 Then begin
    setlength(temp_Buffer,temp_BytesAvailable);
    CreateMesh_AsyncProcess.Output.Read(temp_Buffer[1],temp_BytesAvailable);
    temp_Buffer := StringReplace(temp_Buffer, #13#10, #10, [rfReplaceAll]);
    temp_Buffer := StringReplace(temp_Buffer, #10, #13#10, [rfReplaceAll]);
    CreateMeshSettingsCmdLog_Memo.Lines.Add(WinCPToUTF8(temp_Buffer));
  end;
  //--------------------------------------------------------------------------
end;

procedure TForm1.CreateMesh_AsyncProcessTerminate(Sender: TObject);
var
  temp_str: AnsiString;
begin
  //--------------------------------------------------------------------------
  // 啟用元件
  CreateMeshRun_ToolButton.Enabled:=True;
  CreateMeshParameters_GroupBox.Enabled:=True;
  ForwardModelingParameters_GroupBox.Enabled:=True;
  //--------------------------------------------------------------------------
  //--------------------------------------------------------------------------
  // 更新狀態列
  //--
  if CreateMeshSettingsCmdLog_Memo.Lines.Count=0 Then
  begin
    StatusBar1.Panels[0].Text:='建立模型網格...異常結束!';
    Exit;
  end;
  //--
  // 檢查結果圖片
  temp_str:=CreateMeshSettingsNowJson_Memo.Lines.Strings[41-1];
  temp_str:=StringReplace(temp_str, '"OutputFile06_BasicMeshPNG_FileName":"', '', [rfReplaceAll]);
  temp_str:=StringReplace(temp_str, '",', '', [rfReplaceAll]);
  if FileExists(temp_str) then
  begin
    CreateMeshPreview_Image.Picture.LoadFromFile(temp_str);
    StatusBar1.Panels[0].Text:='建立模型網格...完成!';
    // 成功提示
    temp_str := '成功:' + #13#10 +
      '建立模型網格...完成!';
    Application.MessageBox(PChar(temp_str), '提示', 64);
    Exit;
  end
  else
  begin
    StatusBar1.Panels[0].Text:='建立模型網格...運作異常，請檢查紀錄!';
    Exit;
  end;
  //--------------------------------------------------------------------------
end;

procedure TForm1.FormResize(Sender: TObject);
begin
  //--------------------------------------------------------------------------
  // 限制圖片尺寸，來修補圖片尺寸異常的Bug
  if Forward_PageControl.ActivePage = CreateMesh_TabSheet then
  begin
    CreateMeshPreview_Image.Constraints.MaxWidth:=Form1.Width-Form1CreateMeshPreview_ImageWidthDiffPx;
    CreateMeshPreview_Image.Constraints.MaxHeight:=Form1.Height-Form1CreateMeshPreview_ImageHeightDiffPx;
    ForwardModelingPreview_Image.Constraints.MaxWidth:=Form1.Width-Form1ForwardModelingPreview_ImageWidthDiffPx;
    ForwardModelingPreview_Image.Constraints.MaxHeight:=Form1.Height-Form1ForwardModelingPreview_ImageHeightDiffPx;
  end;
  //--------------------------------------------------------------------------
  //--------------------------------------------------------------------------
  // 限制圖片尺寸，來修補圖片尺寸異常的Bug
  if Forward_PageControl.ActivePage = ForwardModeling_TabSheet then
  begin
    CreateMeshPreview_Image.Constraints.MaxWidth:=Form1.Width-Form1CreateMeshPreview_ImageWidthDiffPx;
    CreateMeshPreview_Image.Constraints.MaxHeight:=Form1.Height-Form1CreateMeshPreview_ImageHeightDiffPx;
    ForwardModelingPreview_Image.Constraints.MaxWidth:=Form1.Width-Form1ForwardModelingPreview_ImageWidthDiffPx;
    ForwardModelingPreview_Image.Constraints.MaxHeight:=Form1.Height-Form1ForwardModelingPreview_ImageHeightDiffPx;
  end;
  //--------------------------------------------------------------------------
end;

procedure TForm1.FormShow(Sender: TObject);
begin
  // 使焦點落在一個沒有用處的東西上面，避免使用者鍵盤操作發生不預期的影響。
  EmptyPanel.SetFocus;
  //--------------------------------------------------------------------------
  // 計算經過DPI縮放後的圖片與主視窗的寬高差，用於修補TImage在不可見的時候會自行改變尺寸的bug。修補方式:手動限制尺寸。
  Form1CreateMeshPreview_ImageWidthDiffPx:=Form1.Width-CreateMeshPreview_Image.Width;
  Form1CreateMeshPreview_ImageHeightDiffPx:=Form1.Height-CreateMeshPreview_Image.Height;
  //--------------------------------------------------------------------------
  //--------------------------------------------------------------------------
  // 計算經過DPI縮放後的圖片與主視窗的寬高差，用於修補TImage在不可見的時候會自行改變尺寸的bug。修補方式:手動限制尺寸。
  // 只能用一開始就有顯示的元件尺寸
  Form1ForwardModelingPreview_ImageWidthDiffPx:=Form1CreateMeshPreview_ImageWidthDiffPx;
  Form1ForwardModelingPreview_ImageHeightDiffPx:=Form1CreateMeshPreview_ImageHeightDiffPx;
  //--------------------------------------------------------------------------
end;

procedure TForm1.ForwardModelingCurrentMode_CheckBoxClick(Sender: TObject);
begin
  //--------------------------------------------------------------------------
  // 控制下拉選單狀態
  if ForwardModelingCurrentMode_CheckBox.Checked then
  begin
    ForwardModelingCurrentMode_ComboBox.Enabled := False;
  end
  else
  begin
    ForwardModelingCurrentMode_ComboBox.Enabled := True;
    if ForwardModelingCurrentMode_ComboBox.ItemIndex < 0 then
    begin
      ForwardModelingCurrentMode_ComboBox.ItemIndex:=0;
    end;
  end;
  //--------------------------------------------------------------------------
end;

procedure TForm1.ForwardModelingOpenOutputFolder_ToolButtonClick(Sender: TObject
  );
var
  temp_str: string;
begin
  // 取得資料夾路徑
  temp_str:=ForwardModelingSettingsDefaultJson_Memo.Lines.Strings[25-1];
  temp_str:=StringReplace(temp_str, '"OutputFolderPath":"', '', [rfReplaceAll]);
  temp_str:=StringReplace(temp_str, '",', '', [rfReplaceAll]);
  temp_str:=ExtractFilePath(Application.ExeName)+temp_str;
  temp_str:=ExtractFilePath(temp_str);
  ForceDirectories(temp_str);
  // 記得在 uses 區塊中加入 Windows, ShellApi
  // 使用 ShellExecute 打開該資料夾
  //ShellExecute(0, 'open', PChar(temp_str), nil, nil, SW_SHOWNORMAL);//這個不支援中文，改用ShellExecuteW
  ShellExecuteW(0, 'open', PWideChar(UTF8ToUTF16(temp_str)), nil, nil, SW_SHOWNORMAL);
end;

procedure TForm1.ForwardModelingRun_ToolButtonClick(Sender: TObject);
var
  temp_i: Integer;
  RegexObj: TRegExpr;
  temp_str: AnsiString;
  temp_StartTime: DWord;
begin
  ForwardModelingSettingsNowJson_Memo.Clear;
  ForwardModelingPreview_Image.Picture.Clear;
  //--
  StatusBar1.Panels[0].Text:='運行順推模擬...請稍後!';
  StatusBar1.Panels[1].Text:='0';
  //--------------------------------------------------------------------------
  ForwardModelingSettingsNowJson_Memo.Lines:=ForwardModelingSettingsDefaultJson_Memo.Lines;
  //--
  if ForwardModelingOutputPNGEnable_CheckBox.Checked then
  begin
    ForwardModelingSettingsNowJson_Memo.Lines.Strings[1] := '"SimulateForTimeSeriesSettings_Version":"v20251101a",';
  end
  else
  begin
    ForwardModelingSettingsNowJson_Memo.Lines.Strings[1] := '"SimulateForTimeSeriesSettings_Version":"v20251031a",';
  end;
  //--
  temp_str:='Output_ERTMaker_CreateAndModifyMesh/'+CreateMeshModelName_Edit.Text+'_SyntheticModel.vtk';
  if FileExists(temp_str) then
  begin
     ForwardModelingSettingsNowJson_Memo.Lines.Strings[4] := '"InputFile01_MeshVTK_FileName":"'+temp_str+'",';
  end
  else
  begin
    temp_str := '錯誤:' + #13#10 +
      'vtk檔案不存在。';
    Application.MessageBox(PChar(temp_str), '錯誤', 16);
    Exit;
  end;
  //--
  temp_str:='Output_ERTMaker_CreateAndModifyMesh/'+CreateMeshModelName_Edit.Text+'_SyntheticModelBCMarkers.json';
  if FileExists(temp_str) then
  begin
     ForwardModelingSettingsNowJson_Memo.Lines.Strings[6] := '"InputFile02_MeshBCMarkersJSON_FileName":"'+temp_str+'",';
  end
  else
  begin
    temp_str := '錯誤:' + #13#10 +
      'json檔案不存在。';
    Application.MessageBox(PChar(temp_str), '錯誤', 16);
    Exit;
  end;
  //--
  temp_str:='Output_ERTMaker_CreateAndModifyMesh/'+CreateMeshModelName_Edit.Text+'_SyntheticModel.ohm';
  if FileExists(temp_str) then
  begin
     ForwardModelingSettingsNowJson_Memo.Lines.Strings[8] := '"InputFile03_OHM_FileName":"'+temp_str+'",';
     ForwardModelingSettingsCmdLog_Memo.Lines.LoadFromFile(temp_str);
  end
  else
  begin
    temp_str := '錯誤:' + #13#10 +
      'ohm檔案不存在。';
    Application.MessageBox(PChar(temp_str), '錯誤', 16);
    Exit;
  end;
  //--
  if ForwardModelingCurrentMode_CheckBox.Checked then
  begin
    for temp_i := 0 to ForwardModelingSettingsCmdLog_Memo.Lines.Count - 1 do
    begin
      if Pos('#x z', ForwardModelingSettingsCmdLog_Memo.Lines[temp_i]) = 1 then
      begin
        // 找到了！
        ForwardModelingCurrentMode_ComboBox.ItemIndex:=-1;
        if ForwardModelingSettingsCmdLog_Memo.Lines.Strings[temp_i-1].ToInteger > 64 then
        begin
          ForwardModelingSettingsNowJson_Memo.Lines.Strings[10] := '"InputFile04_CurrentMode_FileName":"Input_ERTMaker_SimulateForTimeSeries/Configs/v299_S64NCurrentMode/Current Mode.csv",';
        end
        else
        begin
          ForwardModelingSettingsNowJson_Memo.Lines.Strings[10] := '"InputFile04_CurrentMode_FileName":"Input_ERTMaker_SimulateForTimeSeries/Configs/v299_S'+ForwardModelingSettingsCmdLog_Memo.Lines.Strings[temp_i-1]+'NCurrentMode/Current Mode.csv",';
        end;
        Break;          // 立即跳出迴圈，因為找到了第一個目標
      end;
    end;
  end
  else
  begin
    ForwardModelingSettingsNowJson_Memo.Lines.Strings[10] := '"InputFile04_CurrentMode_FileName":"Input_ERTMaker_SimulateForTimeSeries/Configs/v299_'+ForwardModelingCurrentMode_ComboBox.Text+'CurrentMode/Current Mode.csv",';
  end;
  //--
  ForwardModelingSettingsNowJson_Memo.Lines.Strings[18] := '"MeshPNG_Title":"'+CreateMeshModelName_Edit.Text+' Synthetic Model",';
  //--
  ForwardModelingSettingsNowJson_Memo.Lines.Strings[26] := '"Output_MainFileName":"'+CreateMeshModelName_Edit.Text+'_SyntheticModel",';
  //--
  if ForwardModelingOutputPNGEnable_CheckBox.Checked then
  begin
    ForwardModelingSettingsNowJson_Memo.Lines.Strings[28] := '"Output_PNG_Enable":"Yes",';
  end
  else
  begin
    ForwardModelingSettingsNowJson_Memo.Lines.Strings[28] := '"Output_PNG_Enable":"No",';
  end;
  //--
  RegexObj := TRegExpr.Create;
  try
    //--------------------------------------------------------------------------
    // CreateMeshColorbarMinMax_Edit
    RegexObj.Expression := '^\s*([-+]?(\d+\.?\d*|\.\d+))\s*,\s*([-+]?(\d+\.?\d*|\.\d+))\s*$';
    if not RegexObj.Exec(CreateMeshColorbarMinMax_Edit.Text) then
    begin
      // 錯誤的資料內容
      temp_str := '錯誤:' + #13#10 +
        '電阻率色階數值錯誤。請檢查。';
      Application.MessageBox(PChar(temp_str), '錯誤', 16);
      Exit;
    end;
    if StrToFloat(RegexObj.Match[1]) >= StrToFloat(RegexObj.Match[3]) then
    begin
      temp_str := '錯誤:' + #13#10 +
        '電阻率色階最小值必須小於最大值。';
      Application.MessageBox(PChar(temp_str), '錯誤', 16);
      Exit;
    end;
    ForwardModelingSettingsNowJson_Memo.Lines.Strings[20] := ('"MeshPNG_ColorBarResistivityMin":'+RegexObj.Match[1]+',');
    ForwardModelingSettingsNowJson_Memo.Lines.Strings[22] := ('"MeshPNG_ColorBarResistivityMax":'+RegexObj.Match[3]+',');
    //--------------------------------------------------------------------------
    //--------------------------------------------------------------------------
    // ForwardModelingElectrodeIndexABTxVoltageMax_Edit
    RegexObj.Expression := '^[-+]?(\d+(\.\d*)?|\.\d+)$';
    if not RegexObj.Exec(ForwardModelingElectrodeIndexABTxVoltageMax_Edit.Text) then
    begin
      // 錯誤的資料內容
      temp_str := '錯誤:' + #13#10 +
        'AB電極的發射器最大電壓數值錯誤。請檢查。';
      Application.MessageBox(PChar(temp_str), '錯誤', 16);
      Exit;
    end;
    ForwardModelingSettingsNowJson_Memo.Lines.Strings[30] := '"ElectrodeIndexAB_TxVoltageMax":'+ForwardModelingElectrodeIndexABTxVoltageMax_Edit.Text+',';
    //--------------------------------------------------------------------------
    //--------------------------------------------------------------------------
    // ForwardModelingElectrodeIndexABTxCurrentMax_Edit
    RegexObj.Expression := '^[-+]?(\d+(\.\d*)?|\.\d+)$';
    if not RegexObj.Exec(ForwardModelingElectrodeIndexABTxCurrentMax_Edit.Text) then
    begin
      // 錯誤的資料內容
      temp_str := '錯誤:' + #13#10 +
        'AB電極的發射器最大電流數值錯誤。請檢查。';
      Application.MessageBox(PChar(temp_str), '錯誤', 16);
      Exit;
    end;
    ForwardModelingSettingsNowJson_Memo.Lines.Strings[32] := '"ElectrodeIndexAB_TxCurrentMax":'+ForwardModelingElectrodeIndexABTxCurrentMax_Edit.Text+',';
    //--------------------------------------------------------------------------
    //--------------------------------------------------------------------------
    // ForwardModelingElectrodeIndexABResistance_Edit
    RegexObj.Expression := '^[-+]?(\d+(\.\d*)?|\.\d+)$';
    if not RegexObj.Exec(ForwardModelingElectrodeIndexABResistance_Edit.Text) then
    begin
      // 錯誤的資料內容
      temp_str := '錯誤:' + #13#10 +
        'AB電極的接地電阻數值錯誤。請檢查。';
      Application.MessageBox(PChar(temp_str), '錯誤', 16);
      Exit;
    end;
    ForwardModelingSettingsNowJson_Memo.Lines.Strings[34] := '"ElectrodeIndexAB_Resistance":'+ForwardModelingElectrodeIndexABResistance_Edit.Text;
    //--------------------------------------------------------------------------
    //--------------------------------------------------------------------------
    // 儲存預設JSON檔案
    ForceDirectories('Input_ERTMaker_SimulateForTimeSeries');
    ForwardModelingSettingsNowJson_Memo.Lines.SaveToFile('Input_ERTMaker_SimulateForTimeSeries/SimulateForTimeSeriesSettings.json',TEncoding.UTF8);
    //--------------------------------------------------------------------------
    //--------------------------------------------------------------------------
    // 刪除預覽png
    temp_str:=ForwardModelingSettingsNowJson_Memo.Lines.Strings[24]+ForwardModelingSettingsNowJson_Memo.Lines.Strings[26];
    temp_str:=StringReplace(temp_str, '"OutputFolderPath":"', '', [rfReplaceAll]);
    temp_str:=StringReplace(temp_str, '","Output_MainFileName":"', '', [rfReplaceAll]);
    temp_str:=StringReplace(temp_str, '",', '', [rfReplaceAll]);
    temp_str:=temp_str;
    if FileExists(temp_str+'.png') then
    begin
      DeleteFile(PChar(temp_str));
      StatusBar1.Panels[0].Text:='建立模型網格...已刪除舊的預覽圖片，請稍後!';
    end;
    // 刪除結果npy'
    if FileExists(temp_str+'_electric_potential.npy') then
    begin
      DeleteFile(PChar(temp_str));
      StatusBar1.Panels[0].Text:='建立模型網格...已刪除舊的npy，請稍後!';
    end;
    // 刪除結果csv
    if FileExists(temp_str+'_CurrentFlowLinesAB.v299S.csv') then
    begin
      DeleteFile(PChar(temp_str));
      StatusBar1.Panels[0].Text:='建立模型網格...已刪除舊的csv，請稍後!';
    end;
    //--------------------------------------------------------------------------
    //--------------------------------------------------------------------------
    // 等待1秒，讓刪除檔案有時間完成
    temp_StartTime := GetTickCount; // 獲取當前系統時間(ms)
    while(GetTickCount() - temp_StartTime < 1000*1) do//1000*1=等1秒
    begin
      Application.ProcessMessages;
      Sleep(1);//休眠1msend;
    end;
    //--------------------------------------------------------------------------
    //--------------------------------------------------------------------------
    // 外部Python程式檢查
    if not FileExists('PythonEnv\Python.exe') then
    begin
      temp_str := '錯誤:' + #13#10 +
        '外部Python環境不存在。';
      Application.MessageBox(PChar(temp_str), '錯誤', 16);
      Exit;
    end;
    if not FileExists('ERTMaker_SimulateForTimeSeries_v20251031b.cpython-312.pyc') then
    begin
      temp_str := '錯誤:' + #13#10 +
        '外部Python程式不存在。';
      Application.MessageBox(PChar(temp_str), '錯誤', 16);
      Exit;
    end;
    if not FileExists('ERTMaker_SimulateForTimeSeries_v20251101b.cpython-312.pyc') then
    begin
      temp_str := '錯誤:' + #13#10 +
        '外部Python程式不存在。';
      Application.MessageBox(PChar(temp_str), '錯誤', 16);
      Exit;
    end;
    //--------------------------------------------------------------------------
    //--------------------------------------------------------------------------
    ForwardModelingSettingsCmdLog_Memo.Lines.Clear;
    // 使用 CreateMesh_AsyncProcess 運行外部程式
    ForwardModeling_AsyncProcess.Executable:='cmd.exe';
    ForwardModeling_AsyncProcess.Parameters.Clear;
    ForwardModeling_AsyncProcess.Parameters.Add('/c');
    if ForwardModelingOutputPNGEnable_CheckBox.Checked then
    begin
      ForwardModeling_AsyncProcess.Parameters.Add('.\PythonEnv\Python.exe -u ERTMaker_SimulateForTimeSeries_v20251101b.cpython-312.pyc');
    end
    else
    begin
      ForwardModeling_AsyncProcess.Parameters.Add('.\PythonEnv\Python.exe -u ERTMaker_SimulateForTimeSeries_v20251031b.cpython-312.pyc');
    end;
    ForwardModeling_AsyncProcess.Options:=[poUsePipes] + [poNoConsole];
    ForwardModeling_AsyncProcess.Execute;
    // 啟用Timer
    ForwardModeling_Timer.Enabled:=True;
    StatusBar1.Panels[4].Text:='自動播放: 啟用';
    // 禁用元件，等背景運作完再從事件重新啟用按鈕
    ForwardModelingRun_ToolButton.Enabled:=False;
    CreateMeshParameters_GroupBox.Enabled:=False;
    ForwardModelingParameters_GroupBox.Enabled:=False;
    //--------------------------------------------------------------------------
  finally
    RegexObj.Free; // 釋放 TRegExpr 物件
  end;
end;

procedure TForm1.ForwardModeling_AsyncProcessReadData(Sender: TObject);
var
  temp_Buffer:string='';
  temp_BytesAvailable:DWord;
begin
  //--------------------------------------------------------------------------
  // 顯示外部cmd.exe運行內容
  temp_BytesAvailable:=ForwardModeling_AsyncProcess.Output.NumBytesAvailable;
  if temp_BytesAvailable>0 Then begin
    setlength(temp_Buffer,temp_BytesAvailable);
    ForwardModeling_AsyncProcess.Output.Read(temp_Buffer[1],temp_BytesAvailable);
    temp_Buffer := StringReplace(temp_Buffer, #13#10, #10, [rfReplaceAll]);
    temp_Buffer := StringReplace(temp_Buffer, #10, #13#10, [rfReplaceAll]);
    ForwardModelingSettingsCmdLog_Memo.Lines.Add(WinCPToUTF8(temp_Buffer));
  end;
  //--------------------------------------------------------------------------
end;

procedure TForm1.ForwardModeling_AsyncProcessTerminate(Sender: TObject);
var
  temp_str: AnsiString;
begin
  //--------------------------------------------------------------------------
  // 啟用元件
  ForwardModelingRun_ToolButton.Enabled:=True;
  CreateMeshParameters_GroupBox.Enabled:=True;
  ForwardModelingParameters_GroupBox.Enabled:=True;
  //--------------------------------------------------------------------------
  //--------------------------------------------------------------------------
  // 更新狀態列
  //--
  if ForwardModelingSettingsCmdLog_Memo.Lines.Count=0 Then
  begin
    StatusBar1.Panels[0].Text:='運行順推模擬...異常結束!';
    ForwardModeling_Timer.Enabled:=False;
    StatusBar1.Panels[4].Text:='自動播放: 停用';
    Exit;
  end;
  //--
  // 檢查結果csv
  temp_str:=ForwardModelingSettingsNowJson_Memo.Lines.Strings[24]+ForwardModelingSettingsNowJson_Memo.Lines.Strings[26];
  temp_str:=StringReplace(temp_str, '"OutputFolderPath":"', '', [rfReplaceAll]);
  temp_str:=StringReplace(temp_str, '","Output_MainFileName":"', '', [rfReplaceAll]);
  temp_str:=StringReplace(temp_str, '",', '', [rfReplaceAll]);
  temp_str:=temp_str+'_CurrentFlowLinesAB.v299S.csv';
  if FileExists(temp_str) then
  begin
    StatusBar1.Panels[0].Text:='運行順推模擬...完成!';
    // 成功提示
    temp_str := '成功:' + #13#10 +
      '運行順推模擬...完成!';
    Application.MessageBox(PChar(temp_str), '提示', 64);
    Exit;
  end
  else
  begin
    StatusBar1.Panels[0].Text:='運行順推模擬...運作異常，請檢查紀錄!';
    ForwardModeling_Timer.Enabled:=False;
    StatusBar1.Panels[4].Text:='自動播放: 停用';
    Exit;
  end;
  //--------------------------------------------------------------------------
end;

procedure TForm1.ForwardModeling_TimerTimer(Sender: TObject);
var
  temp_str: AnsiString;
begin
  if StrToInt(StatusBar1.Panels[1].Text) = 0 then
  begin
    //--------------------------------------------------------------------------
    // 載入圖片
    temp_str:=ForwardModelingSettingsNowJson_Memo.Lines.Strings[24]+ForwardModelingSettingsNowJson_Memo.Lines.Strings[26];
    temp_str:=StringReplace(temp_str, '"OutputFolderPath":"', '', [rfReplaceAll]);
    temp_str:=StringReplace(temp_str, '","Output_MainFileName":"', '', [rfReplaceAll]);
    temp_str:=StringReplace(temp_str, '",', '', [rfReplaceAll]);
    temp_str:=temp_str;
    if FileExists(temp_str+'_electric_potential.npy') then
    begin
      try
        ForwardModelingPreview_Image.Picture.LoadFromFile(temp_str+'.png');
        if not ForwardModelingOutputPNGEnable_CheckBox.Checked then
        begin
          ForwardModeling_Timer.Enabled:=False;
          StatusBar1.Panels[4].Text:='自動播放: 停用';
        end
        else
        begin
          StatusBar1.Panels[1].Text:='1';
          StatusBar1.Panels[0].Text:='運行順推模擬...請稍後!';
          Exit;
        end;
      except
        StatusBar1.Panels[0].Text:='載入失敗: '+(temp_str+'.png');
      end;
    end;
    //--------------------------------------------------------------------------
  end;
  //--
  if StrToInt(StatusBar1.Panels[1].Text) > 0 then
  begin
    //--------------------------------------------------------------------------
    // 載入圖片
    temp_str:=ForwardModelingSettingsNowJson_Memo.Lines.Strings[24]+ForwardModelingSettingsNowJson_Memo.Lines.Strings[26];
    temp_str:=StringReplace(temp_str, '"OutputFolderPath":"', '', [rfReplaceAll]);
    temp_str:=StringReplace(temp_str, '","Output_MainFileName":"', '', [rfReplaceAll]);
    temp_str:=StringReplace(temp_str, '",', '', [rfReplaceAll]);
    temp_str:=temp_str;
    // 分開檔案的.v299S.csv寫入後再讀取PNG到預覽區
    if FileExists(temp_str+'_CurrentFlowLinesAB_'+Format('%.4d', [StrToInt(StatusBar1.Panels[1].Text)])+'.v299S.csv') and FileExists(temp_str+'_electric_potential.npy') then
    begin
      try
        ForwardModelingPreview_Image.Picture.LoadFromFile(temp_str+'_CurrentFlowLinesAB_'+Format('%.4d', [StrToInt(StatusBar1.Panels[1].Text)])+'.png');
        StatusBar1.Panels[1].Text:=IntToStr(StrToInt(StatusBar1.Panels[1].Text)+1);
        StatusBar1.Panels[0].Text:='運行順推模擬...請稍後!';
      except
        StatusBar1.Panels[0].Text:='載入失敗: '+(temp_str+'_CurrentFlowLinesAB_'+Format('%.4d', [StrToInt(StatusBar1.Panels[1].Text)])+'.png');
      end;
    end
    else if ForwardModelingRun_ToolButton.Enabled then
    begin
      ForwardModeling_Timer.Enabled:=False;
      StatusBar1.Panels[4].Text:='自動播放: 停用';
    end;;
    //--------------------------------------------------------------------------
  end;
  //--
end;

procedure TForm1.InversionModelingDataPrepare_RemoveBadElectrode_CheckBoxChange(
  Sender: TObject);
begin
  //隨 CheckBox 狀態連動 (打勾 = 可用)
  InversionModelingDataPrepare_RemoveBadElectrode_Edit.Enabled := InversionModelingDataPrepare_RemoveBadElectrode_CheckBox.Checked;
end;

procedure TForm1.InversionModelingDataPrepare_UseFakeDataEnable_CheckBoxChange(
  Sender: TObject);
begin
  //隨 CheckBox 狀態連動 (打勾 = 可用)
  InversionModelingDataPrepare_UseFakeDataRhoa_Edit.Enabled := InversionModelingDataPrepare_UseFakeDataEnable_CheckBox.Checked;
end;

procedure TForm1.InversionModelingDataSettings_GroupBoxClick(Sender: TObject);
begin

end;

procedure TForm1.InversionModelingDataSettings_ReCalK_ComboBoxChange(
  Sender: TObject);
begin
  // 只有當選取的文字完全符合 "Ideal_Mesh" 時才啟用
  InversionModelingDataSettings_quality_GroupBox.Enabled := (InversionModelingDataSettings_ReCalK_ComboBox.Text = 'Ideal_Mesh');
  InversionModelingDataSettings_paraDepth_GroupBox.Enabled := (InversionModelingDataSettings_ReCalK_ComboBox.Text = 'Ideal_Mesh');
  InversionModelingDataSettings_boundary_GroupBox.Enabled := (InversionModelingDataSettings_ReCalK_ComboBox.Text = 'Ideal_Mesh');
  InversionModelingDataSettings_paraMaxCellSize_GroupBox.Enabled := (InversionModelingDataSettings_ReCalK_ComboBox.Text = 'Ideal_Mesh');
  InversionModelingDataSettings_addNodes_GroupBox.Enabled := (InversionModelingDataSettings_ReCalK_ComboBox.Text = 'Ideal_Mesh');
  InversionModelingDataSettings_paraDX_GroupBox.Enabled := (InversionModelingDataSettings_ReCalK_ComboBox.Text = 'Ideal_Mesh');
end;

procedure TForm1.InversionModelingInput01Ohm_ManualSelect_ButtonClick(
  Sender: TObject);
begin
  //--------------------------------------------------------------------------
  // OpenDialog1設定對話框標題
  OpenDialog1.Title := '請選擇一個ohm或dat檔案';
  // 設定預設開啟的目錄
  OpenDialog1.InitialDir := Current_Folder_Path;
  // 設定過濾檔案名稱
  OpenDialog1.Filter := '資料檔案(*.ohm;*.dat)|*.ohm;*.dat';
  // 設定開啟選項 (Options)
  // ofFileMustExist: 強制檔案必須存在，否則會跳出警告
  // ofPathMustExist: 強制路徑必須存在
  // ofEnableSizing: 允許調整對話框大小
  OpenDialog1.Options := OpenDialog1.Options + [ofFileMustExist, ofPathMustExist];
  //--
  // 執行選取，如果使用者點擊「開啟」則回傳 True
  if OpenDialog1.Execute then
  begin
    // 取得選取的完整路徑
    //ShowMessage('你選擇了：' + OpenDialog1.FileName);
    InversionModelingInput01Ohm_Edit.Text := OpenDialog1.FileName;
  end
  else
  begin
    // 使用者點擊了「取消」
    //ShowMessage('取消選取');
  end;
end;

procedure TForm1.InversionModelingInput01Ohm_OpenFolder_ButtonClick(
  Sender: TObject);
var
  temp_str: AnsiString;
begin
  // 1. 從完整路徑中提取資料夾路徑
  temp_str := ExtractFilePath(InversionModelingInput01Ohm_Edit.Text);
  // 2. 檢查路徑是否存在
  if DirectoryExists(temp_str) then
  begin
    // 3. 使用系統預設檔案瀏覽器開啟資料夾
    // 記得在 uses 區塊中加入 Windows, ShellApi
    // 使用 ShellExecute 打開該資料夾
    //ShellExecute(0, 'open', PChar(temp_str), nil, nil, SW_SHOWNORMAL);//這個不支援中文，改用ShellExecuteW
    ShellExecuteW(0, 'open', PWideChar(UTF8ToUTF16(temp_str)), nil, nil, SW_SHOWNORMAL);
  end
  else
  begin
    // 如果路徑無效，給予使用者提示
    temp_str := '錯誤:' + #13#10 +
      '資料夾不存在。';
    Application.MessageBox(PChar(temp_str), '錯誤', 16);
  end;
end;

procedure TForm1.InversionModelingInput02VTK_ManualSelect_ButtonClick(
  Sender: TObject);
begin
  //--------------------------------------------------------------------------
  // OpenDialog1設定對話框標題
  OpenDialog1.Title := '請選擇一個ohm或dat檔案';
  // 設定預設開啟的目錄
  OpenDialog1.InitialDir := Current_Folder_Path;
  // 設定過濾檔案名稱
  OpenDialog1.Filter := 'vtk檔案(*.vtk)|*.vtk';
  // 設定開啟選項 (Options)
  // ofFileMustExist: 強制檔案必須存在，否則會跳出警告
  // ofPathMustExist: 強制路徑必須存在
  // ofEnableSizing: 允許調整對話框大小
  OpenDialog1.Options := OpenDialog1.Options + [ofFileMustExist, ofPathMustExist];
  //--
  // 執行選取，如果使用者點擊「開啟」則回傳 True
  if OpenDialog1.Execute then
  begin
    // 取得選取的完整路徑
    //ShowMessage('你選擇了：' + OpenDialog1.FileName);
    InversionModelingInput02VTK_Edit.Text := OpenDialog1.FileName;
  end
  else
  begin
    // 使用者點擊了「取消」
    //ShowMessage('取消選取');
  end;
end;

procedure TForm1.InversionModelingInput02VTK_OpenFolder_ButtonClick(
  Sender: TObject);
var
  temp_str: AnsiString;
begin
  // 1. 從完整路徑中提取資料夾路徑
  temp_str := ExtractFilePath(InversionModelingInput02VTK_Edit.Text);
  // 2. 檢查路徑是否存在
  if DirectoryExists(temp_str) then
  begin
    // 3. 使用系統預設檔案瀏覽器開啟資料夾
    // 記得在 uses 區塊中加入 Windows, ShellApi
    // 使用 ShellExecute 打開該資料夾
    //ShellExecute(0, 'open', PChar(temp_str), nil, nil, SW_SHOWNORMAL);//這個不支援中文，改用ShellExecuteW
    ShellExecuteW(0, 'open', PWideChar(UTF8ToUTF16(temp_str)), nil, nil, SW_SHOWNORMAL);
  end
  else
  begin
    // 如果路徑無效，給予使用者提示
    temp_str := '錯誤:' + #13#10 +
      '資料夾不存在。';
    Application.MessageBox(PChar(temp_str), '錯誤', 16);
  end;
end;

procedure TForm1.InversionModelingInput03MeshJSON_ManualSelect_ButtonClick(
  Sender: TObject);
begin
  //--------------------------------------------------------------------------
  // OpenDialog1設定對話框標題
  OpenDialog1.Title := '請選擇一個ohm或dat檔案';
  // 設定預設開啟的目錄
  OpenDialog1.InitialDir := Current_Folder_Path;
  // 設定過濾檔案名稱
  OpenDialog1.Filter := 'json檔案(*.json)|*.json';
  // 設定開啟選項 (Options)
  // ofFileMustExist: 強制檔案必須存在，否則會跳出警告
  // ofPathMustExist: 強制路徑必須存在
  // ofEnableSizing: 允許調整對話框大小
  OpenDialog1.Options := OpenDialog1.Options + [ofFileMustExist, ofPathMustExist];
  //--
  // 執行選取，如果使用者點擊「開啟」則回傳 True
  if OpenDialog1.Execute then
  begin
    // 取得選取的完整路徑
    //ShowMessage('你選擇了：' + OpenDialog1.FileName);
    InversionModelingInput03MeshJSON_Edit.Text := OpenDialog1.FileName;
  end
  else
  begin
    // 使用者點擊了「取消」
    //ShowMessage('取消選取');
  end;
end;

procedure TForm1.InversionModelingInput03MeshJSON_OpenFolder_ButtonClick(
  Sender: TObject);
var
  temp_str: AnsiString;
begin
  // 1. 從完整路徑中提取資料夾路徑
  temp_str := ExtractFilePath(InversionModelingInput03MeshJSON_Edit.Text);
  // 2. 檢查路徑是否存在
  if DirectoryExists(temp_str) then
  begin
    // 3. 使用系統預設檔案瀏覽器開啟資料夾
    // 記得在 uses 區塊中加入 Windows, ShellApi
    // 使用 ShellExecute 打開該資料夾
    //ShellExecute(0, 'open', PChar(temp_str), nil, nil, SW_SHOWNORMAL);//這個不支援中文，改用ShellExecuteW
    ShellExecuteW(0, 'open', PWideChar(UTF8ToUTF16(temp_str)), nil, nil, SW_SHOWNORMAL);
  end
  else
  begin
    // 如果路徑無效，給予使用者提示
    temp_str := '錯誤:' + #13#10 +
      '資料夾不存在。';
    Application.MessageBox(PChar(temp_str), '錯誤', 16);
  end;
end;

procedure TForm1.InversionModelingInvAutoMesh_Enable_CheckBoxChange(
  Sender: TObject);
begin
  //隨 CheckBox 狀態連動 (打勾 = 可用)
  InversionModelingInvAutoMesh_quality_GroupBox.Enabled := InversionModelingInvAutoMesh_Enable_CheckBox.Checked;
  InversionModelingInvAutoMesh_paraDepth_GroupBox.Enabled := InversionModelingInvAutoMesh_Enable_CheckBox.Checked;
  InversionModelingInvAutoMesh_boundary_GroupBox.Enabled := InversionModelingInvAutoMesh_Enable_CheckBox.Checked;
  InversionModelingInvAutoMesh_paraMaxCellSize_GroupBox.Enabled := InversionModelingInvAutoMesh_Enable_CheckBox.Checked;
  InversionModelingInvAutoMesh_addNodes_GroupBox.Enabled := InversionModelingInvAutoMesh_Enable_CheckBox.Checked;
  InversionModelingInvAutoMesh_paraDX_GroupBox.Enabled := InversionModelingInvAutoMesh_Enable_CheckBox.Checked;
  // 與 CheckBox 狀態相反 (打勾 = 不可用)
  InversionModelingInput02VTK_GroupBox.Enabled := not InversionModelingInvAutoMesh_Enable_CheckBox.Checked;
  InversionModelingInput03MeshJSON_GroupBox.Enabled := not InversionModelingInvAutoMesh_Enable_CheckBox.Checked;
end;

procedure TForm1.InversionModelingInvSettings_XYMinMax_CheckBoxChange(
  Sender: TObject);
begin
  //隨 CheckBox 狀態連動 (打勾 = 可用)
  InversionModelingInvSettings_XYMinMax_Edit.Enabled := InversionModelingInvSettings_XYMinMax_CheckBox.Checked;
end;

procedure TForm1.InversionModelingOpenOutputFolder_ToolButtonClick(
  Sender: TObject);
var
  temp_str: string;
begin
  // 取得資料夾路徑
  temp_str:='Output_ERTMaker_Inversion2D';
  ForceDirectories(temp_str);
  // 記得在 uses 區塊中加入 Windows, ShellApi
  // 使用 ShellExecute 打開該資料夾
  //ShellExecute(0, 'open', PChar(temp_str), nil, nil, SW_SHOWNORMAL);//這個不支援中文，改用ShellExecuteW
  ShellExecuteW(0, 'open', PWideChar(UTF8ToUTF16(temp_str)), nil, nil, SW_SHOWNORMAL);
end;


procedure TForm1.InversionModelingRun_ToolButtonClick(Sender: TObject);
var
  temp_str: AnsiString;
  temp_str1: AnsiString;
  temp_str2: AnsiString;
  temp_str3: AnsiString;
  temp_str4: AnsiString;
  RegexObj: TRegExpr;
begin
  //--------------------------------------------------------------------------
  InversionModelingSettingsCmdLog_Memo.Clear;
  //--
  StatusBar1.Panels[0].Text:='運行逆推模擬...請稍後!';
  StatusBar1.Panels[1].Text:='';
  StatusBar1.Panels[2].Text:='';
  StatusBar1.Panels[3].Text:='';
  StatusBar1.Panels[4].Text:='';
  //--
  if DirectoryExists('Output_ERTMaker_Inversion2D') then
  begin
    // 記得在 uses 區塊中加入 FileUtil
    DeleteDirectory('Output_ERTMaker_Inversion2D', True);// 第二個參數 True 表示如果資料夾裡面有檔案也一併刪除
  end;
  //--
  InversionModelingSettingsNowJson_Memo.Lines:=InversionModelingSettingsDefaultJson_Memo.Lines;
  //--------------------------------------------------------------------------
  temp_str:=InversionModelingInput01Ohm_Edit.Text;
  if FileExists(temp_str) then
  begin
    ForceDirectories('Output_ERTMaker_Inversion2D\Input_Inversion2D\');
    CopyFileW(PWideChar(UTF8ToUTF16(temp_str)),
          PWideChar(UTF8ToUTF16('Output_ERTMaker_Inversion2D\Input_Inversion2D\'+ExtractFileName(temp_str))),
          False);// 第三個參數為 False 表示如果目標已存在則覆蓋 (Overwrite)
    temp_str := 'Output_ERTMaker_Inversion2D\Input_Inversion2D\'+ExtractFileName(temp_str);
    temp_str:=StringReplace(temp_str, '\', '/', [rfReplaceAll]);
    InversionModelingSettingsNowJson_Memo.Lines.Strings[5-1] := ('"InputFile01_Ohm_FileName":"'+temp_str+'",');
  end
  else
  begin
    temp_str := '錯誤:' + #13#10 +
      'ohm/dat檔案不存在。';
    Application.MessageBox(PChar(temp_str), '錯誤', 16);
    Exit;
  end;
  //--------------------------------------------------------------------------
  RegexObj := TRegExpr.Create;
  try
    //--------------------------------------------------------------------------
    if InversionModelingInvAutoMesh_Enable_CheckBox.Checked then
    begin
      //--
      InversionModelingSettingsNowJson_Memo.Lines.Strings[7-1] := ('"Mesh_Setting01_AutoMesh_Enable":"Yes",');
      //--
      InversionModelingSettingsNowJson_Memo.Lines.Strings[9-1] := ('"Mesh_Setting02_AutoMesh_quality":'+InversionModelingInvAutoMesh_quality_ComboBox.Text+',');
      //--
      RegexObj.Expression := '^[-+]?(\d+(\.\d*)?|\.\d+)$';
      if not RegexObj.Exec(InversionModelingInvAutoMesh_paraDepth_Edit.Text) then
      begin
        // 錯誤的資料內容
        temp_str := '錯誤:' + #13#10 +
          '研究區域深度數值錯誤。請檢查。';
        Application.MessageBox(PChar(temp_str), '錯誤', 16);
        Exit;
      end;
      InversionModelingSettingsNowJson_Memo.Lines.Strings[11-1] := ('"Mesh_Setting03_AutoMesh_paraDepth":'+InversionModelingInvAutoMesh_paraDepth_Edit.Text+',');
      //--
      InversionModelingSettingsNowJson_Memo.Lines.Strings[13-1] := ('"Mesh_Setting04_AutoMesh_boundary":'+InversionModelingInvAutoMesh_boundary_ComboBox.Text+',');
      //--
      RegexObj.Expression := '^[+]?(\d+(\.\d*)?|\.\d+)$';
      if not RegexObj.Exec(InversionModelingInvAutoMesh_paraMaxCellSize_Edit.Text) then
      begin
        // 錯誤的資料內容
        temp_str := '錯誤:' + #13#10 +
          '網格面積上限數值錯誤。請檢查。';
        Application.MessageBox(PChar(temp_str), '錯誤', 16);
        Exit;
      end;
      InversionModelingSettingsNowJson_Memo.Lines.Strings[15-1] := ('"Mesh_Setting05_AutoMesh_paraMaxCellSize":'+InversionModelingInvAutoMesh_paraMaxCellSize_Edit.Text+',');
      //--
      RegexObj.Expression := '^\+?\d+$';
      if not RegexObj.Exec(InversionModelingInvAutoMesh_addNodes_Edit.Text) then
      begin
        // 錯誤的資料內容
        temp_str := '錯誤:' + #13#10 +
          'addNodes數值錯誤。請檢查。';
        Application.MessageBox(PChar(temp_str), '錯誤', 16);
        Exit;
      end;
      InversionModelingSettingsNowJson_Memo.Lines.Strings[17-1] := ('"Mesh_Setting06_AutoMesh_addNodes":'+InversionModelingInvAutoMesh_addNodes_Edit.Text+',');
      //--
      RegexObj.Expression := '^[+]?(\d+(\.\d*)?|\.\d+)$';
      if not RegexObj.Exec(InversionModelingInvAutoMesh_paraDX_Edit.Text) then
      begin
        // 錯誤的資料內容
        temp_str := '錯誤:' + #13#10 +
          'paraDX數值錯誤。請檢查。';
        Application.MessageBox(PChar(temp_str), '錯誤', 16);
        Exit;
      end;
      InversionModelingSettingsNowJson_Memo.Lines.Strings[19-1] := ('"Mesh_Setting07_AutoMesh_paraDX":'+InversionModelingInvAutoMesh_paraDX_Edit.Text+',');
      //--
    end
    else
    begin
      temp_str:=InversionModelingInput02VTK_Edit.Text;
      if FileExists(temp_str) then
      begin
        ForceDirectories('Output_ERTMaker_Inversion2D\Input_Inversion2D\');
        CopyFileW(PWideChar(UTF8ToUTF16(temp_str)),
              PWideChar(UTF8ToUTF16('Output_ERTMaker_Inversion2D\Input_Inversion2D\'+ExtractFileName(temp_str))),
              False);// 第三個參數為 False 表示如果目標已存在則覆蓋 (Overwrite)
        temp_str := 'Output_ERTMaker_Inversion2D\Input_Inversion2D\'+ExtractFileName(temp_str);
        temp_str:=StringReplace(temp_str, '\', '/', [rfReplaceAll]);
        InversionModelingSettingsNowJson_Memo.Lines.Strings[21-1] := ('"InputFile02_MeshVTK_FileName":"'+temp_str+'",');
      end
      else
      begin
        temp_str := '錯誤:' + #13#10 +
          'vtk檔案不存在。';
        Application.MessageBox(PChar(temp_str), '錯誤', 16);
        Exit;
      end;
      temp_str:=InversionModelingInput03MeshJSON_Edit.Text;
      if FileExists(temp_str) then
      begin
        ForceDirectories('Output_ERTMaker_Inversion2D\Input_Inversion2D\');
        CopyFileW(PWideChar(UTF8ToUTF16(temp_str)),
              PWideChar(UTF8ToUTF16('Output_ERTMaker_Inversion2D\Input_Inversion2D\'+ExtractFileName(temp_str))),
              False);// 第三個參數為 False 表示如果目標已存在則覆蓋 (Overwrite)
        temp_str := 'Output_ERTMaker_Inversion2D\Input_Inversion2D\'+ExtractFileName(temp_str);
        temp_str:=StringReplace(temp_str, '\', '/', [rfReplaceAll]);
        InversionModelingSettingsNowJson_Memo.Lines.Strings[23-1] := ('"InputFile03_MeshBCMarkersJSON_FileName":"'+temp_str+'",');
      end
      else
      begin
        temp_str := '錯誤:' + #13#10 +
          'json檔案不存在。';
        Application.MessageBox(PChar(temp_str), '錯誤', 16);
        Exit;
      end;
    end;
    //--------------------------------------------------------------------------
    InversionModelingSettingsNowJson_Memo.Lines.Strings[25-1] := ('"Data_Setting00_RecalculateDataMode":"'+InversionModelingDataSettings_ReCalMode_ComboBox.Text+'",');
    //--
    RegexObj.Expression := '^\+?((0\.[0-9]*[1-9][0-9]*)|([1-9][0-9]*(\.[0-9]*)?))$';
    if not RegexObj.Exec(InversionModelingDataSettings_RelativeError_Edit.Text) then
    begin
      // 錯誤的資料內容
      temp_str := '錯誤:' + #13#10 +
        '資料相對誤差數值錯誤。請檢查。';
      Application.MessageBox(PChar(temp_str), '錯誤', 16);
      Exit;
    end;
    InversionModelingSettingsNowJson_Memo.Lines.Strings[27-1] := ('"Data_Setting01_Relative_Error_Percentage":'+InversionModelingDataSettings_RelativeError_Edit.Text+',');
    //--
    InversionModelingSettingsNowJson_Memo.Lines.Strings[29-1] := ('"Data_Setting02_GeometricFactorForInversion":"'+InversionModelingDataSettings_InvK_ComboBox.Text+'",');
    //--
    InversionModelingSettingsNowJson_Memo.Lines.Strings[31-1] := ('"Data_Setting03_GeometricFactorForRecalculateData":"'+InversionModelingDataSettings_ReCalK_ComboBox.Text+'",');
    if  (InversionModelingDataSettings_ReCalK_ComboBox.Text = 'Ideal_Mesh') then
    begin
      //--
      InversionModelingSettingsNowJson_Memo.Lines.Strings[33-1] := ('"Ideal_Mesh_Setting01_AutoMesh_quality":'+InversionModelingDataSettings_quality_ComboBox.Text+',');
      //--
      RegexObj.Expression := '^[-+]?(\d+(\.\d*)?|\.\d+)$';
      if not RegexObj.Exec(InversionModelingDataSettings_paraDepth_Edit.Text) then
      begin
        // 錯誤的資料內容
        temp_str := '錯誤:' + #13#10 +
          '理想網格研究區域深度數值錯誤。請檢查。';
        Application.MessageBox(PChar(temp_str), '錯誤', 16);
        Exit;
      end;
      InversionModelingSettingsNowJson_Memo.Lines.Strings[35-1] := ('"Ideal_Mesh_Setting02_AutoMesh_paraDepth":'+InversionModelingDataSettings_paraDepth_Edit.Text+',');
      //--
      InversionModelingSettingsNowJson_Memo.Lines.Strings[37-1] := ('"Ideal_Mesh_Setting03_AutoMesh_boundary":'+InversionModelingDataSettings_boundary_ComboBox.Text+',');
      //--
      RegexObj.Expression := '^[+]?(\d+(\.\d*)?|\.\d+)$';
      if not RegexObj.Exec(InversionModelingDataSettings_paraMaxCellSize_Edit.Text) then
      begin
        // 錯誤的資料內容
        temp_str := '錯誤:' + #13#10 +
          '理想網格網格面積上限數值錯誤。請檢查。';
        Application.MessageBox(PChar(temp_str), '錯誤', 16);
        Exit;
      end;
      InversionModelingSettingsNowJson_Memo.Lines.Strings[39-1] := ('"Ideal_Mesh_Setting04_AutoMesh_paraMaxCellSize":'+InversionModelingDataSettings_paraMaxCellSize_Edit.Text+',');
      //--
      RegexObj.Expression := '^\+?\d+$';
      if not RegexObj.Exec(InversionModelingDataSettings_addNodes_Edit.Text) then
      begin
        // 錯誤的資料內容
        temp_str := '錯誤:' + #13#10 +
          '理想網格addNodes數值錯誤。請檢查。';
        Application.MessageBox(PChar(temp_str), '錯誤', 16);
        Exit;
      end;
      InversionModelingSettingsNowJson_Memo.Lines.Strings[41-1] := ('"Ideal_Mesh_Setting05_AutoMesh_addNodes":'+InversionModelingDataSettings_addNodes_Edit.Text+',');
      //--
      RegexObj.Expression := '^[+]?(\d+(\.\d*)?|\.\d+)$';
      if not RegexObj.Exec(InversionModelingDataSettings_paraDX_Edit.Text) then
      begin
        // 錯誤的資料內容
        temp_str := '錯誤:' + #13#10 +
          '理想網格paraDX數值錯誤。請檢查。';
        Application.MessageBox(PChar(temp_str), '錯誤', 16);
        Exit;
      end;
      InversionModelingSettingsNowJson_Memo.Lines.Strings[43-1] := ('"Ideal_Mesh_Setting06_AutoMesh_paraDX":'+InversionModelingDataSettings_paraDX_Edit.Text+',');
      //--
    end;
    //--
    //--------------------------------------------------------------------------
    RegexObj.Expression := '^[+]?(\d+(\.\d*)?|\.\d+)$';
    if not RegexObj.Exec(InversionModelingDataPrepare_RemoveCurrentLowerThan_Edit.Text) then
    begin
      // 錯誤的資料內容
      temp_str := '錯誤:' + #13#10 +
        '移除電流低於數值錯誤。請檢查。';
      Application.MessageBox(PChar(temp_str), '錯誤', 16);
      Exit;
    end;
    InversionModelingSettingsNowJson_Memo.Lines.Strings[45-1] := ('"Data_Setting03_RemoveLowCurrentData_LowerThan_A":'+InversionModelingDataPrepare_RemoveCurrentLowerThan_Edit.Text+',');
    //--
    RegexObj.Expression := '^\+?((0\.[0-9]*[1-9][0-9]*)|([1-9][0-9]*(\.[0-9]*)?))$';
    if not RegexObj.Exec(InversionModelingDataPrepare_RemoveCurrentHigherThan_Edit.Text) then
    begin
      // 錯誤的資料內容
      temp_str := '錯誤:' + #13#10 +
        '移除電流高於數值錯誤。請檢查。';
      Application.MessageBox(PChar(temp_str), '錯誤', 16);
      Exit;
    end;
    InversionModelingSettingsNowJson_Memo.Lines.Strings[47-1] := ('"Data_Setting04_RemoveHighCurrentData_HigherThan_A":'+InversionModelingDataPrepare_RemoveCurrentHigherThan_Edit.Text+',');
    //--
    RegexObj.Expression := '^[-+]?(\d+(\.\d*)?|\.\d+)$';
    if not RegexObj.Exec(InversionModelingDataPrepare_RemoveVoltageLowerThan_Edit.Text) then
    begin
      // 錯誤的資料內容
      temp_str := '錯誤:' + #13#10 +
        '移除電壓低於數值錯誤。請檢查。';
      Application.MessageBox(PChar(temp_str), '錯誤', 16);
      Exit;
    end;
    InversionModelingSettingsNowJson_Memo.Lines.Strings[49-1] := ('"Data_Setting05_RemoveLowVoltageData_LowerThan_V":'+InversionModelingDataPrepare_RemoveVoltageLowerThan_Edit.Text+',');
    //--
    RegexObj.Expression := '^[-+]?(\d+(\.\d*)?|\.\d+)$';
    if not RegexObj.Exec(InversionModelingDataPrepare_RemoveVoltageHigherThan_Edit.Text) then
    begin
      // 錯誤的資料內容
      temp_str := '錯誤:' + #13#10 +
        '移除電壓高於數值錯誤。請檢查。';
      Application.MessageBox(PChar(temp_str), '錯誤', 16);
      Exit;
    end;
    InversionModelingSettingsNowJson_Memo.Lines.Strings[51-1] := ('"Data_Setting06_RemoveHighVoltageData_HigherThan_V":'+InversionModelingDataPrepare_RemoveVoltageHigherThan_Edit.Text+',');
    //--
    RegexObj.Expression := '^[+]?(\d+(\.\d*)?|\.\d+)$';
    if not RegexObj.Exec(InversionModelingDataPrepare_RemoveAppResLowerThan_Edit.Text) then
    begin
      // 錯誤的資料內容
      temp_str := '錯誤:' + #13#10 +
        '移除視電阻率低於數值錯誤。請檢查。';
      Application.MessageBox(PChar(temp_str), '錯誤', 16);
      Exit;
    end;
    InversionModelingSettingsNowJson_Memo.Lines.Strings[53-1] := ('"Data_Setting07_RemoveLowAppResData_LowerThan_OhmM":'+InversionModelingDataPrepare_RemoveAppResLowerThan_Edit.Text+',');
    //--
    RegexObj.Expression := '^[+]?(\d+(\.\d*)?|\.\d+)$';
    if not RegexObj.Exec(InversionModelingDataPrepare_RemoveAppResHigherThan_Edit.Text) then
    begin
      // 錯誤的資料內容
      temp_str := '錯誤:' + #13#10 +
        '移除視電阻率高於數值錯誤。請檢查。';
      Application.MessageBox(PChar(temp_str), '錯誤', 16);
      Exit;
    end;
    InversionModelingSettingsNowJson_Memo.Lines.Strings[55-1] := ('"Data_Setting08_RemoveHighAppResData_HigherThan_OhmM":'+InversionModelingDataPrepare_RemoveAppResHigherThan_Edit.Text+',');
    //--
    if InversionModelingDataPrepare_RemoveBadElectrode_CheckBox.Checked then
    begin
      RegexObj.Expression := '^\d+(,\d+)*$';
      if not RegexObj.Exec(InversionModelingDataPrepare_RemoveBadElectrode_Edit.Text) then
      begin
        // 錯誤的資料內容
        temp_str := '錯誤:' + #13#10 +
          '移除電極索引數值錯誤。請檢查。';
        Application.MessageBox(PChar(temp_str), '錯誤', 16);
        Exit;
      end;
      InversionModelingSettingsNowJson_Memo.Lines.Strings[57-1] := ('"Data_Setting09_RemoveBadElectrodeData_List":['+InversionModelingDataPrepare_RemoveBadElectrode_Edit.Text+'],');
      //--
    end;
    //--
    if InversionModelingDataPrepare_UseFakeDataEnable_CheckBox.Checked then
    begin
      InversionModelingSettingsNowJson_Memo.Lines.Strings[63-1] := ('"Data_Setting12_UseFakeData_Enable":"Yes",');
      //--
      RegexObj.Expression := '^\+?((0\.[0-9]*[1-9][0-9]*)|([1-9][0-9]*(\.[0-9]*)?))$';
      if not RegexObj.Exec(InversionModelingDataPrepare_UseFakeDataRhoa_Edit.Text) then
      begin
        // 錯誤的資料內容
        temp_str := '錯誤:' + #13#10 +
          '電阻率取代數值錯誤。請檢查。';
        Application.MessageBox(PChar(temp_str), '錯誤', 16);
        Exit;
      end;
      InversionModelingSettingsNowJson_Memo.Lines.Strings[65-1] := ('"Data_Setting13_UseFakeData_rhoa":'+InversionModelingDataPrepare_UseFakeDataRhoa_Edit.Text+',');
      //--
    end;
    //--
    RegexObj.Expression := '^\+?\d+$';
    if not RegexObj.Exec(InversionModelingInvSettings_RemoveTimes_Edit.Text) then
    begin
      // 錯誤的資料內容
      temp_str := '錯誤:' + #13#10 +
        '資料剔除次數數值錯誤。請檢查。';
      Application.MessageBox(PChar(temp_str), '錯誤', 16);
      Exit;
    end;
    InversionModelingSettingsNowJson_Memo.Lines.Strings[73-1] := ('"Inversion_Setting01_Remove_Data_Times":'+InversionModelingInvSettings_RemoveTimes_Edit.Text+',');
    //--
    RegexObj.Expression := '^\+?([1-9][0-9]?)$';
    if not RegexObj.Exec(InversionModelingInvSettings_RemovePercentage_Edit.Text) then
    begin
      // 錯誤的資料內容
      temp_str := '錯誤:' + #13#10 +
        '資料剔除[%]數值錯誤。請檢查。';
      Application.MessageBox(PChar(temp_str), '錯誤', 16);
      Exit;
    end;
    InversionModelingSettingsNowJson_Memo.Lines.Strings[75-1] := ('"Inversion_Setting02_Remove_Data_Percentage":'+InversionModelingInvSettings_RemovePercentage_Edit.Text+',');
    //--
    RegexObj.Expression := '^\[\s*\d+(\.\d*)?\s*(,\s*\d+(\.\d*)?\s*)*\]$';
    if not RegexObj.Exec(InversionModelingInvSettings_Lambda_Edit.Text) then
    begin
      // 錯誤的資料內容
      temp_str := '錯誤:' + #13#10 +
        'Lambda數值錯誤。請檢查。';
      Application.MessageBox(PChar(temp_str), '錯誤', 16);
      Exit;
    end;
    InversionModelingSettingsNowJson_Memo.Lines.Strings[77-1] := ('"Inversion_Setting03_Lamda":'+InversionModelingInvSettings_Lambda_Edit.Text+',');
    //--
    RegexObj.Expression := '^\+?\d+$';
    if not RegexObj.Exec(InversionModelingInvSettings_maxIter_Edit.Text) then
    begin
      // 錯誤的資料內容
      temp_str := '錯誤:' + #13#10 +
        '最大迭代次數數值錯誤。請檢查。';
      Application.MessageBox(PChar(temp_str), '錯誤', 16);
      Exit;
    end;
    InversionModelingSettingsNowJson_Memo.Lines.Strings[79-1] := ('"Inversion_Setting04_maxIter":'+InversionModelingInvSettings_maxIter_Edit.Text+',');
    //--
    RegexObj.Expression := '^([1-9]\d*|-(1|2|3))$';
    if not RegexObj.Exec(InversionModelingInvSettings_startModel_Edit.Text) then
    begin
      // 錯誤的資料內容
      temp_str := '錯誤:' + #13#10 +
        '逆推起始模型數值錯誤。請檢查。';
      Application.MessageBox(PChar(temp_str), '錯誤', 16);
      Exit;
    end;
    InversionModelingSettingsNowJson_Memo.Lines.Strings[81-1] := ('"Inversion_Setting05_startModel":'+InversionModelingInvSettings_startModel_Edit.Text+',');
    //--
    if (InversionModelingInvSettings_startModel_Edit.Text = '-3') then
    begin
      temp_str:='Input_ERTMaker_Inversion2D/InputFile05_StudyAreaStartModelVTK.vtk';
      if FileExists(temp_str) then
      begin
        InversionModelingSettingsNowJson_Memo.Lines.Strings[83-1] := ('"InputFile05_StudyAreaStartModelVTK_FileName":"'+temp_str+'",');
        CopyFileW(PWideChar(UTF8ToUTF16(temp_str)),
          PWideChar(UTF8ToUTF16('Output_ERTMaker_Inversion2D/Input_Inversion2D/'+ExtractFileName(temp_str))),
          False);// 第三個參數為 False 表示如果目標已存在則覆蓋 (Overwrite)
      end
      else
      begin
        temp_str := '錯誤:' + #13#10 +
          '逆推起始模型vtk檔案不存在。';
        Application.MessageBox(PChar(temp_str), '錯誤', 16);
        Exit;
      end;
    end;
    //--
    if InversionModelingOutputSettings_verbose_ComboBox.Text = '停用' then
    begin
      InversionModelingSettingsNowJson_Memo.Lines.Strings[85-1] := ('"Inversion_Setting06_verbose_Enable":"No",');
    end;
    //--
    RegexObj.Expression := '^\[\s*(\d+(\.\d*)?|\.\d+)\s*,\s*(\d+(\.\d*)?|\.\d+)\s*\]$';
    if not RegexObj.Exec(InversionModelingInvSettings_limitModelCell_Edit.Text) then
    begin
      // 錯誤的資料內容
      temp_str := '錯誤:' + #13#10 +
        '模型電阻率範圍數值錯誤。請檢查。';
      Application.MessageBox(PChar(temp_str), '錯誤', 16);
      Exit;
    end;
    temp_str := InversionModelingInvSettings_limitModelCell_Edit.Text;
    temp_str1 := temp_str.Substring(1, temp_str.IndexOf(',') - 1);
    //--
    temp_str := InversionModelingInvSettings_limitModelCell_Edit.Text;
    temp_str2 := temp_str.Substring(temp_str.IndexOf(',') + 1).Trim([']']);
    //--
    if (StrToFloat(temp_str1) = 0) and (StrToFloat(temp_str2) = 0) then
    begin
      InversionModelingSettingsNowJson_Memo.Lines.Strings[87-1] := ('"Inversion_Setting07_limitModelCellMinValue":'+temp_str1+',');
      InversionModelingSettingsNowJson_Memo.Lines.Strings[89-1] := ('"Inversion_Setting08_limitModelCellMaxValue":'+temp_str2+',');
    end
    else if StrToFloat(temp_str1) < StrToFloat(temp_str2) then
    begin
      InversionModelingSettingsNowJson_Memo.Lines.Strings[87-1] := ('"Inversion_Setting07_limitModelCellMinValue":'+temp_str1+',');
      InversionModelingSettingsNowJson_Memo.Lines.Strings[89-1] := ('"Inversion_Setting08_limitModelCellMaxValue":'+temp_str2+',');
    end
    else
    begin
      // 錯誤的資料內容
      temp_str := '錯誤:' + #13#10 +
        '模型電阻率範圍數值大小錯誤。請檢查。';
      Application.MessageBox(PChar(temp_str), '錯誤', 16);
      Exit;
    end;
    //--
    RegexObj.Expression := '^[^\\/:\*\?"<>\|]+$';
    if not RegexObj.Exec(InversionModelingOutputSettings_MainName_Edit.Text) then
    begin
      // 錯誤的資料內容
      temp_str := '錯誤:' + #13#10 +
        '測線名稱錯誤。請檢查。';
      Application.MessageBox(PChar(temp_str), '錯誤', 16);
      Exit;
    end;
    InversionModelingSettingsNowJson_Memo.Lines.Strings[95-1] := ('"Output_MainFileName":"'+InversionModelingOutputSettings_MainName_Edit.Text+'",');
    //--
    RegexObj.Expression := '^\[\s*(\d+(\.\d*)?|\.\d+)\s*,\s*(\d+(\.\d*)?|\.\d+)\s*\]$';
    if not RegexObj.Exec(InversionModelingInvSettings_ColorBar_Edit.Text) then
    begin
      // 錯誤的資料內容
      temp_str := '錯誤:' + #13#10 +
        '色階範圍數值錯誤。請檢查。';
      Application.MessageBox(PChar(temp_str), '錯誤', 16);
      Exit;
    end;
    temp_str := InversionModelingInvSettings_ColorBar_Edit.Text;
    temp_str1 := temp_str.Substring(1, temp_str.IndexOf(',') - 1);
    //--
    temp_str := InversionModelingInvSettings_ColorBar_Edit.Text;
    temp_str2 := temp_str.Substring(temp_str.IndexOf(',') + 1).Trim([']']);
    //--
    if StrToFloat(temp_str1) < StrToFloat(temp_str2) then
    begin
      InversionModelingSettingsNowJson_Memo.Lines.Strings[97-1] := ('"Output_Inversion_ColorBarResistivityMin":'+temp_str1+',');
      InversionModelingSettingsNowJson_Memo.Lines.Strings[99-1] := ('"Output_Inversion_ColorBarResistivityMax":'+temp_str2+',');
    end
    else
    begin
      // 錯誤的資料內容
      temp_str := '錯誤:' + #13#10 +
        '裁切範圍數值大小錯誤。請檢查。';
      Application.MessageBox(PChar(temp_str), '錯誤', 16);
      Exit;
    end;
    //--
    if InversionModelingInvSettings_XYMinMax_CheckBox.Checked then
    begin
      InversionModelingSettingsNowJson_Memo.Lines.Strings[101-1] := ('"Output_Inversion_XMinMax_Enable":"Yes",');
      //--
      RegexObj.Expression := '^\[\s*(-?\d+(\.\d*)?|-?\.\d+)\s*,\s*(-?\d+(\.\d*)?|-?\.\d+)\s*,\s*(-?\d+(\.\d*)?|-?\.\d+)\s*,\s*(-?\d+(\.\d*)?|-?\.\d+)\s*\]$';
      if not RegexObj.Exec(InversionModelingInvSettings_XYMinMax_Edit.Text) then
      begin
        // 錯誤的資料內容
        temp_str := '錯誤:' + #13#10 +
          '裁切範圍數值錯誤。請檢查。';
        Application.MessageBox(PChar(temp_str), '錯誤', 16);
        Exit;
      end;
      temp_str := InversionModelingInvSettings_XYMinMax_Edit.Text;
      temp_str1 := temp_str.Substring(1, temp_str.IndexOf(',') - 1);
      //--
      temp_str := InversionModelingInvSettings_XYMinMax_Edit.Text;
      temp_str := temp_str.Substring(temp_str.IndexOf(',') + 1);
      temp_str2 := temp_str.Substring(0, temp_str.IndexOf(','));
      //--
      temp_str := InversionModelingInvSettings_XYMinMax_Edit.Text;
      temp_str := temp_str.Substring(temp_str.IndexOf(',') + 1);
      temp_str := temp_str.Substring(temp_str.IndexOf(',') + 1);
      temp_str3 := temp_str.Substring(0, temp_str.IndexOf(','));
      //--
      temp_str := InversionModelingInvSettings_XYMinMax_Edit.Text;
      temp_str := temp_str.Substring(temp_str.IndexOf(',') + 1);
      temp_str := temp_str.Substring(temp_str.IndexOf(',') + 1);
      temp_str := temp_str.Substring(temp_str.IndexOf(',') + 1);
      temp_str4 := temp_str.Substring(0, temp_str.Length - 1);
      //--
      if StrToFloat(temp_str1) < StrToFloat(temp_str2) then
      begin
        InversionModelingSettingsNowJson_Memo.Lines.Strings[103-1] := ('"Output_Inversion_XMin":'+temp_str1+',');
        InversionModelingSettingsNowJson_Memo.Lines.Strings[105-1] := ('"Output_Inversion_XMax":'+temp_str2+',');
      end
      else
      begin
        // 錯誤的資料內容
        temp_str := '錯誤:' + #13#10 +
          '裁切範圍數值大小錯誤。請檢查。';
        Application.MessageBox(PChar(temp_str), '錯誤', 16);
        Exit;
      end;
      //--
      if StrToFloat(temp_str3) < StrToFloat(temp_str4) then
      begin
        InversionModelingSettingsNowJson_Memo.Lines.Strings[107-1] := ('"Output_Inversion_YMin":'+temp_str3+',');
       InversionModelingSettingsNowJson_Memo.Lines.Strings[109-1] := ('"Output_Inversion_YMax":'+temp_str4+',');
      end
      else
      begin
        // 錯誤的資料內容
        temp_str := '錯誤:' + #13#10 +
          '裁切範圍數值大小錯誤。請檢查。';
        Application.MessageBox(PChar(temp_str), '錯誤', 16);
        Exit;
      end;
      //--
    end;
    //--------------------------------------------------------------------------
    //--------------------------------------------------------------------------
    // 儲存預設JSON檔案
    ForceDirectories('Input_ERTMaker_Inversion2D');
    InversionModelingSettingsNowJson_Memo.Lines.SaveToFile('Input_ERTMaker_Inversion2D/Inversion2D.json',TEncoding.UTF8);
    InversionModelingSettingsNowJson_Memo.Lines.SaveToFile('Output_ERTMaker_Inversion2D/Input_Inversion2D/Inversion2D.json',TEncoding.UTF8);
    //--------------------------------------------------------------------------
    //--------------------------------------------------------------------------
    // 外部Python程式檢查
    if not FileExists('PythonEnv\Python.exe') then
    begin
      temp_str := '錯誤:' + #13#10 +
        '外部Python環境不存在。';
      Application.MessageBox(PChar(temp_str), '錯誤', 16);
      Exit;
    end;
    if not FileExists('ERTMaker_Inversion2D_v20260401a.cpython-312.pyc') then
    begin
      temp_str := '錯誤:' + #13#10 +
        '外部Python程式不存在。';
      Application.MessageBox(PChar(temp_str), '錯誤', 16);
      Exit;
    end;
    //--------------------------------------------------------------------------
    //--------------------------------------------------------------------------
    InversionModelingSettingsCmdLog_Memo.Lines.Clear;
    // 使用 InversionModeling_AsyncProcess 運行外部程式
    InversionModeling_AsyncProcess.Executable:='cmd.exe';
    InversionModeling_AsyncProcess.Parameters.Clear;
    InversionModeling_AsyncProcess.Parameters.Add('/c');
    InversionModeling_AsyncProcess.Parameters.Add('set PYTHONIOENCODING=utf-8 && .\PythonEnv\Python.exe -u ERTMaker_Inversion2D_v20260401a.cpython-312.pyc');
    InversionModeling_AsyncProcess.Options:=[poUsePipes, poStderrToOutPut, poNoConsole];
    InversionModeling_AsyncProcess.Execute;
    // 啟用Timer
    //ForwardModeling_Timer.Enabled:=True;
    //StatusBar1.Panels[4].Text:='自動播放: 啟用';
    // 禁用元件，等背景運作完再從事件重新啟用按鈕
    Forward_TabSheet.Enabled:=False;
    InversionModelingRun_ToolButton.Enabled:=False;
    InversionModelingParameters_GroupBox.Enabled:=False;
    //--------------------------------------------------------------------------
  finally
    RegexObj.Free; // 釋放 TRegExpr 物件
  end;
  //--------------------------------------------------------------------------
end;

procedure TForm1.InversionModeling_AsyncProcessReadData(Sender: TObject);
var
  temp_Buffer:string='';
  temp_BytesAvailable:DWord;
begin
  //--------------------------------------------------------------------------
  // 顯示外部cmd.exe運行內容
  temp_BytesAvailable:=InversionModeling_AsyncProcess.Output.NumBytesAvailable;
  if temp_BytesAvailable>0 Then begin
    setlength(temp_Buffer,temp_BytesAvailable);
    InversionModeling_AsyncProcess.Output.Read(temp_Buffer[1],temp_BytesAvailable);
    temp_Buffer := StringReplace(temp_Buffer, #13#10, #10, [rfReplaceAll]);
    temp_Buffer := StringReplace(temp_Buffer, #10, #13#10, [rfReplaceAll]);
    //InversionModelingSettingsCmdLog_Memo.Lines.Add(WinCPToUTF8(temp_Buffer));
    // 當呼叫Python程式強制使用UTF-8時，不需要重新編碼
    InversionModelingSettingsCmdLog_Memo.Lines.Add(temp_Buffer);
  end;
  //--------------------------------------------------------------------------
end;

procedure TForm1.InversionModeling_AsyncProcessTerminate(Sender: TObject);
var
  temp_str: AnsiString;
begin
  //--------------------------------------------------------------------------
  // 啟用元件
  Forward_TabSheet.Enabled:=True;
  InversionModelingRun_ToolButton.Enabled:=True;
  InversionModelingParameters_GroupBox.Enabled:=True;
  //--------------------------------------------------------------------------
  //--------------------------------------------------------------------------
  // 更新狀態列
  //--
  if InversionModelingSettingsCmdLog_Memo.Lines.Count=0 Then
  begin
    StatusBar1.Panels[0].Text:='運行逆推模擬...異常結束!';
    Exit;
  end;
  //--
  // 檢查結果log
  temp_str :='Output_ERTMaker_Inversion2D/ERTMaker_Inversion2D.log';
  if FileExists(temp_str) then
  begin
    StatusBar1.Panels[0].Text:='運行逆推模擬...完成!';
    // 成功提示
    temp_str := '成功:' + #13#10 +
      '運行逆推模擬...完成!';
    Application.MessageBox(PChar(temp_str), '提示', 64);
    Exit;
  end
  else
  begin
    StatusBar1.Panels[0].Text:='運行逆推模擬...運作異常，請檢查紀錄!';
    Exit;
  end;
  //--------------------------------------------------------------------------
end;

procedure TForm1.MainMenu1_1_1Click(Sender: TObject);
var
  temp_str: AnsiString;
begin
  temp_str:='作者: HsiupoYeh.'+#13#10+'程式版本: '+version_str+#13#10+'數值模擬運算核心: PyGIMLi v1.5.4';
  Application.MessageBox(PChar(temp_str),'關於我',64);
end;

procedure TForm1.StatusBar1Resize(Sender: TObject);
var
  temp_remain_width: Integer;
begin
  // --
  // 計算剩餘空間
  temp_remain_width := StatusBar1.Width;

  // --
  // 先配置最後一格（索引4），希望是200
  //
  StatusBar1.Panels.Items[4].Width := 200;
  // 計算剩餘空間
  temp_remain_width := temp_remain_width - StatusBar1.Panels.Items[4].Width;

  // --
  // 配置隔壁一格（索引3），希望是150
  //
  StatusBar1.Panels.Items[3].Width := 150;
  if temp_remain_width < StatusBar1.Panels.Items[3].Width then
  begin
    StatusBar1.Panels.Items[3].Width := temp_remain_width;
  end;
  // 計算剩餘空間
  temp_remain_width := temp_remain_width - StatusBar1.Panels.Items[3].Width;

  // --
  // 配置隔壁一格（索引2），希望是150
  //
  StatusBar1.Panels.Items[2].Width := 150;
  if temp_remain_width < StatusBar1.Panels.Items[2].Width then
  begin
    StatusBar1.Panels.Items[2].Width := temp_remain_width;
  end;
  // 計算剩餘空間
  temp_remain_width := temp_remain_width - StatusBar1.Panels.Items[2].Width;

  // --
  // 配置隔壁一格（索引1），希望是150
  //
  StatusBar1.Panels.Items[1].Width := 150;
  if temp_remain_width < StatusBar1.Panels.Items[1].Width then
  begin
    StatusBar1.Panels.Items[1].Width := temp_remain_width;
  end;
  // 計算剩餘空間
  temp_remain_width := temp_remain_width - StatusBar1.Panels.Items[1].Width;

  // --
  // 最前方一格（索引0）享受最大空間
  //
  StatusBar1.Panels.Items[0].Width := temp_remain_width;

  // --
end;

procedure TForm1.TimeSeriesProcessingInput01Geo_AutoDetect_ButtonClick(
  Sender: TObject);
var
  temp_str: AnsiString;
begin
  temp_str := 'Output_ERTMaker_CreateAndModifyMesh\'+CreateMeshModelName_Edit.Text+'_SyntheticModel.geo';
  TimeSeriesProcessingInput01Geo_Edit.Text := temp_str;
  if FileExists(temp_str) then
  begin
    //Application.MessageBox(PChar(temp_str), '檔案存在!', 64);
  end
  else
  begin
    temp_str := '錯誤:' + #13#10 + 'geo檔案不存在。';
    Application.MessageBox(PChar(temp_str), '錯誤', 16);
    TimeSeriesProcessingInput01Geo_Edit.Text := '';
    Exit;
  end;
end;

procedure TForm1.TimeSeriesProcessingInput01Geo_ManualSelect_ButtonClick(
  Sender: TObject);
begin
  //--------------------------------------------------------------------------
  // OpenDialog1設定對話框標題
  OpenDialog1.Title := '請選擇一個geo檔案';
  // 設定預設開啟的目錄
  OpenDialog1.InitialDir := Current_Folder_Path;
  // 設定過濾檔案名稱
  OpenDialog1.Filter := 'geo檔案(*.geo)|*.geo';
  // 設定開啟選項 (Options)
  // ofFileMustExist: 強制檔案必須存在，否則會跳出警告
  // ofPathMustExist: 強制路徑必須存在
  // ofEnableSizing: 允許調整對話框大小
  OpenDialog1.Options := OpenDialog1.Options + [ofFileMustExist, ofPathMustExist];
  //--
  // 執行選取，如果使用者點擊「開啟」則回傳 True
  if OpenDialog1.Execute then
  begin
    // 取得選取的完整路徑
    //ShowMessage('你選擇了：' + OpenDialog1.FileName);
    TimeSeriesProcessingInput01Geo_Edit.Text := OpenDialog1.FileName;
  end
  else
  begin
    // 使用者點擊了「取消」
    //ShowMessage('取消選取');
  end;
end;

procedure TForm1.TimeSeriesProcessingInput01Geo_OpenFolder_ButtonClick(
  Sender: TObject);
var
  temp_str: AnsiString;
begin
  // 1. 從完整路徑中提取資料夾路徑
  temp_str := ExtractFilePath(TimeSeriesProcessingInput01Geo_Edit.Text);
  // 2. 檢查路徑是否存在
  if DirectoryExists(temp_str) then
  begin
    // 3. 使用系統預設檔案瀏覽器開啟資料夾
    // 記得在 uses 區塊中加入 Windows, ShellApi
    // 使用 ShellExecute 打開該資料夾
    //ShellExecute(0, 'open', PChar(temp_str), nil, nil, SW_SHOWNORMAL);//這個不支援中文，改用ShellExecuteW
    ShellExecuteW(0, 'open', PWideChar(UTF8ToUTF16(temp_str)), nil, nil, SW_SHOWNORMAL);
  end
  else
  begin
    // 如果路徑無效，給予使用者提示
    temp_str := '錯誤:' + #13#10 +
      '資料夾不存在。';
    Application.MessageBox(PChar(temp_str), '錯誤', 16);
  end;
end;

procedure TForm1.TimeSeriesProcessingInput02Ohm_AutoDetect_ButtonClick(
  Sender: TObject);
var
  temp_str: AnsiString;
begin
  temp_str := 'Output_ERTMaker_CreateAndModifyMesh\'+CreateMeshModelName_Edit.Text+'_SyntheticModel.ohm';
  TimeSeriesProcessingInput02Ohm_Edit.Text := temp_str;
  if FileExists(temp_str) then
  begin
    //Application.MessageBox(PChar(temp_str), '檔案存在!', 64);
  end
  else
  begin
    temp_str := '錯誤:' + #13#10 + 'ohm檔案不存在。';
    Application.MessageBox(PChar(temp_str), '錯誤', 16);
    TimeSeriesProcessingInput02Ohm_Edit.Text := '';
    Exit;
  end;
end;

procedure TForm1.TimeSeriesProcessingInput02Ohm_ManualSelect_ButtonClick(
  Sender: TObject);
begin
  //--------------------------------------------------------------------------
  // OpenDialog1設定對話框標題
  OpenDialog1.Title := '請選擇一個ohm檔案';
  // 設定預設開啟的目錄
  OpenDialog1.InitialDir := Current_Folder_Path;
  // 設定過濾檔案名稱
  OpenDialog1.Filter := 'ohm檔案(*.ohm)|*.ohm';
  // 設定開啟選項 (Options)
  // ofFileMustExist: 強制檔案必須存在，否則會跳出警告
  // ofPathMustExist: 強制路徑必須存在
  // ofEnableSizing: 允許調整對話框大小
  OpenDialog1.Options := OpenDialog1.Options + [ofFileMustExist, ofPathMustExist];
  //--
  // 執行選取，如果使用者點擊「開啟」則回傳 True
  if OpenDialog1.Execute then
  begin
    // 取得選取的完整路徑
    //ShowMessage('你選擇了：' + OpenDialog1.FileName);
    TimeSeriesProcessingInput02Ohm_Edit.Text := OpenDialog1.FileName;
  end
  else
  begin
    // 使用者點擊了「取消」
    //ShowMessage('取消選取');
  end;
end;

procedure TForm1.TimeSeriesProcessingInput02Ohm_OpenFolder_ButtonClick(
  Sender: TObject);
var
  temp_str: AnsiString;
begin
  // 1. 從完整路徑中提取資料夾路徑
  temp_str := ExtractFilePath(TimeSeriesProcessingInput02Ohm_Edit.Text);
  // 2. 檢查路徑是否存在
  if DirectoryExists(temp_str) then
  begin
    // 3. 使用系統預設檔案瀏覽器開啟資料夾
    // 記得在 uses 區塊中加入 Windows, ShellApi
    // 使用 ShellExecute 打開該資料夾
    //ShellExecute(0, 'open', PChar(temp_str), nil, nil, SW_SHOWNORMAL);//這個不支援中文，改用ShellExecuteW
    ShellExecuteW(0, 'open', PWideChar(UTF8ToUTF16(temp_str)), nil, nil, SW_SHOWNORMAL);
  end
  else
  begin
    // 如果路徑無效，給予使用者提示
    temp_str := '錯誤:' + #13#10 +
      '資料夾不存在。';
    Application.MessageBox(PChar(temp_str), '錯誤', 16);
  end;
end;

procedure TForm1.TimeSeriesProcessingInput03v299Scsv_AutoDetect_ButtonClick(
  Sender: TObject);
var
  temp_str: AnsiString;
begin
  temp_str := 'Output_ERTMaker_SimulateForTimeSeries\'+CreateMeshModelName_Edit.Text+'_SyntheticModel_CurrentFlowLinesAB.v299S.csv';
  TimeSeriesProcessingInput03v299Scsv_Edit.Text := temp_str;
  if FileExists(temp_str) then
  begin
    //Application.MessageBox(PChar(temp_str), '檔案存在!', 64);
  end
  else
  begin
    temp_str := '錯誤:' + #13#10 + 'csv檔案不存在。';
    Application.MessageBox(PChar(temp_str), '錯誤', 16);
    TimeSeriesProcessingInput03v299Scsv_Edit.Text := '';
    Exit;
  end;
end;

procedure TForm1.TimeSeriesProcessingInput03v299Scsv_ManualSelect_ButtonClick(
  Sender: TObject);
begin
  //--------------------------------------------------------------------------
  // OpenDialog1設定對話框標題
  OpenDialog1.Title := '請選擇一個v299Scsv檔案';
  // 設定預設開啟的目錄
  OpenDialog1.InitialDir := Current_Folder_Path;
  // 設定過濾檔案名稱
  OpenDialog1.Filter := 'v299Scsv檔案(*.csv)|*.csv';
  // 設定開啟選項 (Options)
  // ofFileMustExist: 強制檔案必須存在，否則會跳出警告
  // ofPathMustExist: 強制路徑必須存在
  // ofEnableSizing: 允許調整對話框大小
  OpenDialog1.Options := OpenDialog1.Options + [ofFileMustExist, ofPathMustExist];
  //--
  // 執行選取，如果使用者點擊「開啟」則回傳 True
  if OpenDialog1.Execute then
  begin
    // 取得選取的完整路徑
    //ShowMessage('你選擇了：' + OpenDialog1.FileName);
    TimeSeriesProcessingInput03v299Scsv_Edit.Text := OpenDialog1.FileName;
  end
  else
  begin
    // 使用者點擊了「取消」
    //ShowMessage('取消選取');
  end;
end;

procedure TForm1.TimeSeriesProcessingInput03v299Scsv_OpenFolder_ButtonClick(
  Sender: TObject);
var
  temp_str: AnsiString;
begin
  // 1. 從完整路徑中提取資料夾路徑
  temp_str := ExtractFilePath(TimeSeriesProcessingInput03v299Scsv_Edit.Text);
  // 2. 檢查路徑是否存在
  if DirectoryExists(temp_str) then
  begin
    // 3. 使用系統預設檔案瀏覽器開啟資料夾
    // 記得在 uses 區塊中加入 Windows, ShellApi
    // 使用 ShellExecute 打開該資料夾
    //ShellExecute(0, 'open', PChar(temp_str), nil, nil, SW_SHOWNORMAL);//這個不支援中文，改用ShellExecuteW
    ShellExecuteW(0, 'open', PWideChar(UTF8ToUTF16(temp_str)), nil, nil, SW_SHOWNORMAL);
  end
  else
  begin
    // 如果路徑無效，給予使用者提示
    temp_str := '錯誤:' + #13#10 +
      '資料夾不存在。';
    Application.MessageBox(PChar(temp_str), '錯誤', 16);
  end;
end;

procedure TForm1.TimeSeriesProcessingInput04ABMN_AutoDetect_ButtonClick(
  Sender: TObject);
var
  temp_str: AnsiString;
begin
  temp_str := 'Output_ERTMaker_CreateAndModifyMesh\'+CreateMeshModelName_Edit.Text+'_SyntheticModel.abmn';
  TimeSeriesProcessingInput04ABMN_Edit.Text := temp_str;
  if FileExists(temp_str) then
  begin
    //Application.MessageBox(PChar(temp_str), '檔案存在!', 64);
  end
  else
  begin
    // 檔案不存在，建立一個空白檔案
    try
      // 如果資料夾不存在，ForceDirectories 會自動建立它們
      ForceDirectories(ExtractFilePath(temp_str));
      // 建立一個空白檔案
      TFileStream.Create(temp_str, fmCreate).Free;
      temp_str := '提示:' + #13#10 + '找不到abmn檔案，已自動創建空白檔案！';
      Application.MessageBox(PChar(temp_str), '提示', 64);
    except
      on E: Exception do
      begin
        // 捕捉所有錯誤（例如資料夾不存在、唯讀權限、檔名非法字元等）
        temp_str := '錯誤:' + #13#10 + '建立檔案時發生意外錯誤：' + E.Message;
        Application.MessageBox(PChar(temp_str), '錯誤', 16);
        TimeSeriesProcessingInput04ABMN_Edit.Text := '';
        Exit;
      end;
    end;
  end;
end;

procedure TForm1.TimeSeriesProcessingInput04ABMN_ManualSelect_ButtonClick(
  Sender: TObject);
begin
  //--------------------------------------------------------------------------
  // OpenDialog1設定對話框標題
  OpenDialog1.Title := '請選擇一個abmn檔案';
  // 設定預設開啟的目錄
  OpenDialog1.InitialDir := Current_Folder_Path;
  // 設定過濾檔案名稱
  OpenDialog1.Filter := 'abmn檔案(*.abmn)|*.abmn';
  // 設定開啟選項 (Options)
  // ofFileMustExist: 強制檔案必須存在，否則會跳出警告
  // ofPathMustExist: 強制路徑必須存在
  // ofEnableSizing: 允許調整對話框大小
  OpenDialog1.Options := OpenDialog1.Options + [ofFileMustExist, ofPathMustExist];
  //--
  // 執行選取，如果使用者點擊「開啟」則回傳 True
  if OpenDialog1.Execute then
  begin
    // 取得選取的完整路徑
    //ShowMessage('你選擇了：' + OpenDialog1.FileName);
    TimeSeriesProcessingInput04ABMN_Edit.Text := OpenDialog1.FileName;
  end
  else
  begin
    // 使用者點擊了「取消」
    //ShowMessage('取消選取');
  end;
end;

procedure TForm1.TimeSeriesProcessingInput04ABMN_OpenFolder_ButtonClick(
  Sender: TObject);
var
  temp_str: AnsiString;
begin
  // 1. 從完整路徑中提取資料夾路徑
  temp_str := ExtractFilePath(TimeSeriesProcessingInput04ABMN_Edit.Text);
  // 2. 檢查路徑是否存在
  if DirectoryExists(temp_str) then
  begin
    // 3. 使用系統預設檔案瀏覽器開啟資料夾
    // 記得在 uses 區塊中加入 Windows, ShellApi
    // 使用 ShellExecute 打開該資料夾
    //ShellExecute(0, 'open', PChar(temp_str), nil, nil, SW_SHOWNORMAL);//這個不支援中文，改用ShellExecuteW
    ShellExecuteW(0, 'open', PWideChar(UTF8ToUTF16(temp_str)), nil, nil, SW_SHOWNORMAL);
  end
  else
  begin
    // 如果路徑無效，給予使用者提示
    temp_str := '錯誤:' + #13#10 +
      '資料夾不存在。';
    Application.MessageBox(PChar(temp_str), '錯誤', 16);
  end;
end;

procedure TForm1.TimeSeriesProcessingOpenOutputFolder_ToolButtonClick(
  Sender: TObject);
var
  temp_str: string;
begin
  // 取得資料夾路徑
  temp_str:='Output_ERTMaker_v299ScsvToUrf';
  ForceDirectories(temp_str);
  // 記得在 uses 區塊中加入 Windows, ShellApi
  // 使用 ShellExecute 打開該資料夾
  //ShellExecute(0, 'open', PChar(temp_str), nil, nil, SW_SHOWNORMAL);//這個不支援中文，改用ShellExecuteW
  ShellExecuteW(0, 'open', PWideChar(UTF8ToUTF16(temp_str)), nil, nil, SW_SHOWNORMAL);
end;

procedure TForm1.TimeSeriesProcessingRun_ToolButtonClick(Sender: TObject);
var
  temp_str: AnsiString;
begin
  //--------------------------------------------------------------------------
  TimeSeriesProcessingSettingsNowJson_Memo.Clear;
  //--
  StatusBar1.Panels[0].Text:='運行時間序列解算...請稍後!';
  //--
  if DirectoryExists('Output_ERTMaker_v299ScsvToUrf') then
  begin
    // 記得在 uses 區塊中加入 FileUtil
    DeleteDirectory('Output_ERTMaker_v299ScsvToUrf', True);// 第二個參數 True 表示如果資料夾裡面有檔案也一併刪除
  end;
  //--
  TimeSeriesProcessingSettingsNowJson_Memo.Lines:=TimeSeriesProcessingSettingsDefaultJson_Memo.Lines;
  //--------------------------------------------------------------------------
  temp_str:=TimeSeriesProcessingInput01Geo_Edit.Text;
  if FileExists(temp_str) then
  begin
    ForceDirectories('Output_ERTMaker_v299ScsvToUrf\Input_v299ScsvToUrf\');
    CopyFileW(PWideChar(UTF8ToUTF16(temp_str)),
          PWideChar(UTF8ToUTF16('Output_ERTMaker_v299ScsvToUrf\Input_v299ScsvToUrf\'+ExtractFileName(temp_str))),
          False);// 第三個參數為 False 表示如果目標已存在則覆蓋 (Overwrite)
    temp_str := 'Output_ERTMaker_v299ScsvToUrf\Input_v299ScsvToUrf\'+ExtractFileName(temp_str);
    temp_str:=StringReplace(temp_str, '\', '/', [rfReplaceAll]);
    TimeSeriesProcessingSettingsNowJson_Memo.Lines.Strings[5-1] := ('"InputFile01_Geo_FileName":"'+temp_str+'",');
  end
  else
  begin
    temp_str := '錯誤:' + #13#10 +
      'geo檔案不存在。';
    Application.MessageBox(PChar(temp_str), '錯誤', 16);
    StatusBar1.Panels[0].Text:='錯誤:geo檔案不存在。';
    Exit;
  end;
  //--------------------------------------------------------------------------
  temp_str:=TimeSeriesProcessingInput02Ohm_Edit.Text;
  if FileExists(temp_str) then
  begin
    ForceDirectories('Output_ERTMaker_v299ScsvToUrf\Input_v299ScsvToUrf\');
    CopyFileW(PWideChar(UTF8ToUTF16(temp_str)),
          PWideChar(UTF8ToUTF16('Output_ERTMaker_v299ScsvToUrf\Input_v299ScsvToUrf\'+ExtractFileName(temp_str))),
          False);// 第三個參數為 False 表示如果目標已存在則覆蓋 (Overwrite)
    temp_str := 'Output_ERTMaker_v299ScsvToUrf\Input_v299ScsvToUrf\'+ExtractFileName(temp_str);
    temp_str:=StringReplace(temp_str, '\', '/', [rfReplaceAll]);
    TimeSeriesProcessingSettingsNowJson_Memo.Lines.Strings[7-1] := ('"InputFile02_Ohm_FileName":"'+temp_str+'",');
  end
  else
  begin
    temp_str := '錯誤:' + #13#10 +
      'ohm檔案不存在。';
    Application.MessageBox(PChar(temp_str), '錯誤', 16);
    StatusBar1.Panels[0].Text:='錯誤:ohm檔案不存在。';
    Exit;
  end;
  //--------------------------------------------------------------------------
  temp_str:=TimeSeriesProcessingInput03v299Scsv_Edit.Text;
  if FileExists(temp_str) then
  begin
    ForceDirectories('Output_ERTMaker_v299ScsvToUrf\Input_v299ScsvToUrf\');
    CopyFileW(PWideChar(UTF8ToUTF16(temp_str)),
          PWideChar(UTF8ToUTF16('Output_ERTMaker_v299ScsvToUrf\Input_v299ScsvToUrf\'+ExtractFileName(temp_str))),
          False);// 第三個參數為 False 表示如果目標已存在則覆蓋 (Overwrite)
    //--
    temp_str := 'Output_ERTMaker_v299ScsvToUrf\Input_v299ScsvToUrf\'+ExtractFileName(temp_str);
    temp_str  :=StringReplace(temp_str, '\', '/', [rfReplaceAll]);
    TimeSeriesProcessingSettingsNowJson_Memo.Lines.Strings[9-1] := ('"InputFile03_v299Scsv_FileName":"'+temp_str+'",');
    //--
    temp_str := 'Output_ERTMaker_v299ScsvToUrf\Output_v299ScsvToUrf\'+ChangeFileExt(ExtractFileName(temp_str),'.urf');
    temp_str := StringReplace(temp_str, '\', '/', [rfReplaceAll]);
    TimeSeriesProcessingSettingsNowJson_Memo.Lines.Strings[13-1] := ('"OutputFile01_Urf_All_FileName":"'+temp_str+'",');
    //--
    TimeSeriesProcessingSettingsNowJson_Memo.Lines.Strings[15-1] := TimeSeriesProcessingSettingsNowJson_Memo.Lines.Strings[13-1];
    TimeSeriesProcessingSettingsNowJson_Memo.Lines.Strings[15-1] := StringReplace(TimeSeriesProcessingSettingsNowJson_Memo.Lines.Strings[15-1], 'OutputFile01_Urf_All_FileName', 'OutputFile02_Urf_All_SNR_FileName', [rfReplaceAll]);
    TimeSeriesProcessingSettingsNowJson_Memo.Lines.Strings[15-1] := StringReplace(TimeSeriesProcessingSettingsNowJson_Memo.Lines.Strings[15-1], '.urf"', '.SNR.urf"', [rfReplaceAll]);
    //--
    TimeSeriesProcessingSettingsNowJson_Memo.Lines.Strings[17-1] := TimeSeriesProcessingSettingsNowJson_Memo.Lines.Strings[13-1];
    TimeSeriesProcessingSettingsNowJson_Memo.Lines.Strings[17-1] := StringReplace(TimeSeriesProcessingSettingsNowJson_Memo.Lines.Strings[17-1], 'OutputFile01_Urf_All_FileName', 'OutputFile03_Ohm_All_FileName', [rfReplaceAll]);
    TimeSeriesProcessingSettingsNowJson_Memo.Lines.Strings[17-1] := StringReplace(TimeSeriesProcessingSettingsNowJson_Memo.Lines.Strings[17-1], '.urf"', '.ohm"', [rfReplaceAll]);
    //--
    TimeSeriesProcessingSettingsNowJson_Memo.Lines.Strings[19-1] := TimeSeriesProcessingSettingsNowJson_Memo.Lines.Strings[13-1];
    TimeSeriesProcessingSettingsNowJson_Memo.Lines.Strings[19-1] := StringReplace(TimeSeriesProcessingSettingsNowJson_Memo.Lines.Strings[19-1], 'OutputFile01_Urf_All_FileName', 'OutputFile04_PNG_All_MainFileName', [rfReplaceAll]);
    TimeSeriesProcessingSettingsNowJson_Memo.Lines.Strings[19-1] := StringReplace(TimeSeriesProcessingSettingsNowJson_Memo.Lines.Strings[19-1], '.urf"', '"', [rfReplaceAll]);
    //--
    TimeSeriesProcessingSettingsNowJson_Memo.Lines.Strings[23-1] := TimeSeriesProcessingSettingsNowJson_Memo.Lines.Strings[13-1];
    TimeSeriesProcessingSettingsNowJson_Memo.Lines.Strings[23-1] := StringReplace(TimeSeriesProcessingSettingsNowJson_Memo.Lines.Strings[23-1], 'OutputFile01_Urf_All_FileName', 'OutputFile05_Urf_WS_FileName', [rfReplaceAll]);
    TimeSeriesProcessingSettingsNowJson_Memo.Lines.Strings[23-1] := StringReplace(TimeSeriesProcessingSettingsNowJson_Memo.Lines.Strings[23-1], '.urf"', '.WS.urf"', [rfReplaceAll]);
    //--
    TimeSeriesProcessingSettingsNowJson_Memo.Lines.Strings[25-1] := TimeSeriesProcessingSettingsNowJson_Memo.Lines.Strings[13-1];
    TimeSeriesProcessingSettingsNowJson_Memo.Lines.Strings[25-1] := StringReplace(TimeSeriesProcessingSettingsNowJson_Memo.Lines.Strings[25-1], 'OutputFile01_Urf_All_FileName', 'OutputFile06_Urf_WS_SNR_FileName', [rfReplaceAll]);
    TimeSeriesProcessingSettingsNowJson_Memo.Lines.Strings[25-1] := StringReplace(TimeSeriesProcessingSettingsNowJson_Memo.Lines.Strings[25-1], '.urf"', '.WS.SNR.urf"', [rfReplaceAll]);
    //--
    TimeSeriesProcessingSettingsNowJson_Memo.Lines.Strings[27-1] := TimeSeriesProcessingSettingsNowJson_Memo.Lines.Strings[13-1];
    TimeSeriesProcessingSettingsNowJson_Memo.Lines.Strings[27-1] := StringReplace(TimeSeriesProcessingSettingsNowJson_Memo.Lines.Strings[27-1], 'OutputFile01_Urf_All_FileName', 'OutputFile07_Ohm_WS_FileName', [rfReplaceAll]);
    TimeSeriesProcessingSettingsNowJson_Memo.Lines.Strings[27-1] := StringReplace(TimeSeriesProcessingSettingsNowJson_Memo.Lines.Strings[27-1], '.urf"', '.WS.ohm"', [rfReplaceAll]);
    //--
    TimeSeriesProcessingSettingsNowJson_Memo.Lines.Strings[29-1] := TimeSeriesProcessingSettingsNowJson_Memo.Lines.Strings[13-1];
    TimeSeriesProcessingSettingsNowJson_Memo.Lines.Strings[29-1] := StringReplace(TimeSeriesProcessingSettingsNowJson_Memo.Lines.Strings[29-1], 'OutputFile01_Urf_All_FileName', 'OutputFile08_PNG_WS_MainFileName', [rfReplaceAll]);
    TimeSeriesProcessingSettingsNowJson_Memo.Lines.Strings[29-1] := StringReplace(TimeSeriesProcessingSettingsNowJson_Memo.Lines.Strings[29-1], '.urf"', '.WS"', [rfReplaceAll]);
    //--
    TimeSeriesProcessingSettingsNowJson_Memo.Lines.Strings[33-1] := TimeSeriesProcessingSettingsNowJson_Memo.Lines.Strings[13-1];
    TimeSeriesProcessingSettingsNowJson_Memo.Lines.Strings[33-1] := StringReplace(TimeSeriesProcessingSettingsNowJson_Memo.Lines.Strings[33-1], 'OutputFile01_Urf_All_FileName', 'OutputFile09_Urf_MGD_FileName', [rfReplaceAll]);
    TimeSeriesProcessingSettingsNowJson_Memo.Lines.Strings[33-1] := StringReplace(TimeSeriesProcessingSettingsNowJson_Memo.Lines.Strings[33-1], '.urf"', '.MGD.urf"', [rfReplaceAll]);
    //--
    TimeSeriesProcessingSettingsNowJson_Memo.Lines.Strings[35-1] := TimeSeriesProcessingSettingsNowJson_Memo.Lines.Strings[13-1];
    TimeSeriesProcessingSettingsNowJson_Memo.Lines.Strings[35-1] := StringReplace(TimeSeriesProcessingSettingsNowJson_Memo.Lines.Strings[35-1], 'OutputFile01_Urf_All_FileName', 'OutputFile10_Urf_MGD_SNR_FileName', [rfReplaceAll]);
    TimeSeriesProcessingSettingsNowJson_Memo.Lines.Strings[35-1] := StringReplace(TimeSeriesProcessingSettingsNowJson_Memo.Lines.Strings[35-1], '.urf"', '.MGD.SNR.urf"', [rfReplaceAll]);
    //--
    TimeSeriesProcessingSettingsNowJson_Memo.Lines.Strings[37-1] := TimeSeriesProcessingSettingsNowJson_Memo.Lines.Strings[13-1];
    TimeSeriesProcessingSettingsNowJson_Memo.Lines.Strings[37-1] := StringReplace(TimeSeriesProcessingSettingsNowJson_Memo.Lines.Strings[37-1], 'OutputFile01_Urf_All_FileName', 'OutputFile11_Ohm_MGD_FileName', [rfReplaceAll]);
    TimeSeriesProcessingSettingsNowJson_Memo.Lines.Strings[37-1] := StringReplace(TimeSeriesProcessingSettingsNowJson_Memo.Lines.Strings[37-1], '.urf"', '.MGD.ohm"', [rfReplaceAll]);
    //--
    TimeSeriesProcessingSettingsNowJson_Memo.Lines.Strings[39-1] := TimeSeriesProcessingSettingsNowJson_Memo.Lines.Strings[13-1];
    TimeSeriesProcessingSettingsNowJson_Memo.Lines.Strings[39-1] := StringReplace(TimeSeriesProcessingSettingsNowJson_Memo.Lines.Strings[39-1], 'OutputFile01_Urf_All_FileName', 'OutputFile12_PNG_MGD_MainFileName', [rfReplaceAll]);
    TimeSeriesProcessingSettingsNowJson_Memo.Lines.Strings[39-1] := StringReplace(TimeSeriesProcessingSettingsNowJson_Memo.Lines.Strings[39-1], '.urf"', '.MGD"', [rfReplaceAll]);
    //--
    TimeSeriesProcessingSettingsNowJson_Memo.Lines.Strings[43-1] := TimeSeriesProcessingSettingsNowJson_Memo.Lines.Strings[13-1];
    TimeSeriesProcessingSettingsNowJson_Memo.Lines.Strings[43-1] := StringReplace(TimeSeriesProcessingSettingsNowJson_Memo.Lines.Strings[43-1], 'OutputFile01_Urf_All_FileName', 'OutputFile13_Urf_MPR_FileName', [rfReplaceAll]);
    TimeSeriesProcessingSettingsNowJson_Memo.Lines.Strings[43-1] := StringReplace(TimeSeriesProcessingSettingsNowJson_Memo.Lines.Strings[43-1], '.urf"', '.MPR.urf"', [rfReplaceAll]);
    //--
    TimeSeriesProcessingSettingsNowJson_Memo.Lines.Strings[45-1] := TimeSeriesProcessingSettingsNowJson_Memo.Lines.Strings[13-1];
    TimeSeriesProcessingSettingsNowJson_Memo.Lines.Strings[45-1] := StringReplace(TimeSeriesProcessingSettingsNowJson_Memo.Lines.Strings[45-1], 'OutputFile01_Urf_All_FileName', 'OutputFile14_Urf_MPR_SNR_FileName', [rfReplaceAll]);
    TimeSeriesProcessingSettingsNowJson_Memo.Lines.Strings[45-1] := StringReplace(TimeSeriesProcessingSettingsNowJson_Memo.Lines.Strings[45-1], '.urf"', '.MPR.SNR.urf"', [rfReplaceAll]);
    //--
    TimeSeriesProcessingSettingsNowJson_Memo.Lines.Strings[47-1] := TimeSeriesProcessingSettingsNowJson_Memo.Lines.Strings[13-1];
    TimeSeriesProcessingSettingsNowJson_Memo.Lines.Strings[47-1] := StringReplace(TimeSeriesProcessingSettingsNowJson_Memo.Lines.Strings[47-1], 'OutputFile01_Urf_All_FileName', 'OutputFile15_Ohm_MPR_FileName', [rfReplaceAll]);
    TimeSeriesProcessingSettingsNowJson_Memo.Lines.Strings[47-1] := StringReplace(TimeSeriesProcessingSettingsNowJson_Memo.Lines.Strings[47-1], '.urf"', '.MPR.ohm"', [rfReplaceAll]);
    //--
    TimeSeriesProcessingSettingsNowJson_Memo.Lines.Strings[49-1] := TimeSeriesProcessingSettingsNowJson_Memo.Lines.Strings[13-1];
    TimeSeriesProcessingSettingsNowJson_Memo.Lines.Strings[49-1] := StringReplace(TimeSeriesProcessingSettingsNowJson_Memo.Lines.Strings[49-1], 'OutputFile01_Urf_All_FileName', 'OutputFile16_PNG_MPR_MainFileName', [rfReplaceAll]);
    TimeSeriesProcessingSettingsNowJson_Memo.Lines.Strings[49-1] := StringReplace(TimeSeriesProcessingSettingsNowJson_Memo.Lines.Strings[49-1], '.urf"', '.MPR"', [rfReplaceAll]);
    //--
    TimeSeriesProcessingSettingsNowJson_Memo.Lines.Strings[53-1] := TimeSeriesProcessingSettingsNowJson_Memo.Lines.Strings[13-1];
    TimeSeriesProcessingSettingsNowJson_Memo.Lines.Strings[53-1] := StringReplace(TimeSeriesProcessingSettingsNowJson_Memo.Lines.Strings[53-1], 'OutputFile01_Urf_All_FileName', 'OutputFile17_Urf_GD_FileName', [rfReplaceAll]);
    TimeSeriesProcessingSettingsNowJson_Memo.Lines.Strings[53-1] := StringReplace(TimeSeriesProcessingSettingsNowJson_Memo.Lines.Strings[53-1], '.urf"', '.GD.urf"', [rfReplaceAll]);
    //--
    TimeSeriesProcessingSettingsNowJson_Memo.Lines.Strings[55-1] := TimeSeriesProcessingSettingsNowJson_Memo.Lines.Strings[13-1];
    TimeSeriesProcessingSettingsNowJson_Memo.Lines.Strings[55-1] := StringReplace(TimeSeriesProcessingSettingsNowJson_Memo.Lines.Strings[55-1], 'OutputFile01_Urf_All_FileName', 'OutputFile18_Urf_GD_SNR_FileName', [rfReplaceAll]);
    TimeSeriesProcessingSettingsNowJson_Memo.Lines.Strings[55-1] := StringReplace(TimeSeriesProcessingSettingsNowJson_Memo.Lines.Strings[55-1], '.urf"', '.GD.SNR.urf"', [rfReplaceAll]);
    //--
    TimeSeriesProcessingSettingsNowJson_Memo.Lines.Strings[57-1] := TimeSeriesProcessingSettingsNowJson_Memo.Lines.Strings[13-1];
    TimeSeriesProcessingSettingsNowJson_Memo.Lines.Strings[57-1] := StringReplace(TimeSeriesProcessingSettingsNowJson_Memo.Lines.Strings[57-1], 'OutputFile01_Urf_All_FileName', 'OutputFile19_Ohm_GD_FileName', [rfReplaceAll]);
    TimeSeriesProcessingSettingsNowJson_Memo.Lines.Strings[57-1] := StringReplace(TimeSeriesProcessingSettingsNowJson_Memo.Lines.Strings[57-1], '.urf"', '.GD.ohm"', [rfReplaceAll]);
    //--
    TimeSeriesProcessingSettingsNowJson_Memo.Lines.Strings[59-1] := TimeSeriesProcessingSettingsNowJson_Memo.Lines.Strings[13-1];
    TimeSeriesProcessingSettingsNowJson_Memo.Lines.Strings[59-1] := StringReplace(TimeSeriesProcessingSettingsNowJson_Memo.Lines.Strings[59-1], 'OutputFile01_Urf_All_FileName', 'OutputFile20_PNG_GD_MainFileName', [rfReplaceAll]);
    TimeSeriesProcessingSettingsNowJson_Memo.Lines.Strings[59-1] := StringReplace(TimeSeriesProcessingSettingsNowJson_Memo.Lines.Strings[59-1], '.urf"', '.GD"', [rfReplaceAll]);
    //--
    TimeSeriesProcessingSettingsNowJson_Memo.Lines.Strings[75-1] := TimeSeriesProcessingSettingsNowJson_Memo.Lines.Strings[13-1];
    TimeSeriesProcessingSettingsNowJson_Memo.Lines.Strings[75-1] := StringReplace(TimeSeriesProcessingSettingsNowJson_Memo.Lines.Strings[75-1], 'OutputFile01_Urf_All_FileName', 'OutputFile21_Urf_Select_FileName', [rfReplaceAll]);
    TimeSeriesProcessingSettingsNowJson_Memo.Lines.Strings[75-1] := StringReplace(TimeSeriesProcessingSettingsNowJson_Memo.Lines.Strings[75-1], '.urf"', '.Select.urf"', [rfReplaceAll]);
    //--
    TimeSeriesProcessingSettingsNowJson_Memo.Lines.Strings[77-1] := TimeSeriesProcessingSettingsNowJson_Memo.Lines.Strings[13-1];
    TimeSeriesProcessingSettingsNowJson_Memo.Lines.Strings[77-1] := StringReplace(TimeSeriesProcessingSettingsNowJson_Memo.Lines.Strings[77-1], 'OutputFile01_Urf_All_FileName', 'OutputFile22_Urf_Select_SNR_FileName', [rfReplaceAll]);
    TimeSeriesProcessingSettingsNowJson_Memo.Lines.Strings[77-1] := StringReplace(TimeSeriesProcessingSettingsNowJson_Memo.Lines.Strings[77-1], '.urf"', '.Select.SNR.urf"', [rfReplaceAll]);
    //--
    TimeSeriesProcessingSettingsNowJson_Memo.Lines.Strings[79-1] := TimeSeriesProcessingSettingsNowJson_Memo.Lines.Strings[13-1];
    TimeSeriesProcessingSettingsNowJson_Memo.Lines.Strings[79-1] := StringReplace(TimeSeriesProcessingSettingsNowJson_Memo.Lines.Strings[79-1], 'OutputFile01_Urf_All_FileName', 'OutputFile23_Ohm_Select_FileName', [rfReplaceAll]);
    TimeSeriesProcessingSettingsNowJson_Memo.Lines.Strings[79-1] := StringReplace(TimeSeriesProcessingSettingsNowJson_Memo.Lines.Strings[79-1], '.urf"', '.Select.ohm"', [rfReplaceAll]);
    //--
    TimeSeriesProcessingSettingsNowJson_Memo.Lines.Strings[81-1] := TimeSeriesProcessingSettingsNowJson_Memo.Lines.Strings[13-1];
    TimeSeriesProcessingSettingsNowJson_Memo.Lines.Strings[81-1] := StringReplace(TimeSeriesProcessingSettingsNowJson_Memo.Lines.Strings[81-1], 'OutputFile01_Urf_All_FileName', 'OutputFile24_PNG_Select_MainFileName', [rfReplaceAll]);
    TimeSeriesProcessingSettingsNowJson_Memo.Lines.Strings[81-1] := StringReplace(TimeSeriesProcessingSettingsNowJson_Memo.Lines.Strings[81-1], '.urf"', '.Select"', [rfReplaceAll]);
    //--
  end
  else
  begin
    temp_str := '錯誤:' + #13#10 +
      'csv檔案不存在。';
    Application.MessageBox(PChar(temp_str), '錯誤', 16);
    StatusBar1.Panels[0].Text:='錯誤:csv檔案不存在。';
    Exit;
  end;
  //--------------------------------------------------------------------------
  temp_str:=TimeSeriesProcessingInput04ABMN_Edit.Text;
  if FileExists(temp_str) then
  begin
    // ABMN檔案是否為空，空的就關閉檔案清單篩選
    if (FileSize(temp_str) > 0) then
    begin
      TimeSeriesProcessingSettingsNowJson_Memo.Lines.Strings[73-1] := '"Select_Keep_ABMN_Enable":"Yes",';
    end
    else
    begin
      TimeSeriesProcessingSettingsNowJson_Memo.Lines.Strings[73-1] := '"Select_Keep_ABMN_Enable":"No",';
    end;
    ForceDirectories('Output_ERTMaker_v299ScsvToUrf\Input_v299ScsvToUrf\');
    CopyFileW(PWideChar(UTF8ToUTF16(temp_str)),
          PWideChar(UTF8ToUTF16('Output_ERTMaker_v299ScsvToUrf\Input_v299ScsvToUrf\'+ExtractFileName(temp_str))),
          False);// 第三個參數為 False 表示如果目標已存在則覆蓋 (Overwrite)
    temp_str := 'Output_ERTMaker_v299ScsvToUrf\Input_v299ScsvToUrf\'+ExtractFileName(temp_str);
    temp_str:=StringReplace(temp_str, '\', '/', [rfReplaceAll]);
    TimeSeriesProcessingSettingsNowJson_Memo.Lines.Strings[11-1] := ('"InputFile04_Keep_ABMN_FileName":"'+temp_str+'",');
  end
  else
  begin
    temp_str := '錯誤:' + #13#10 +
      'abmn檔案不存在。';
    Application.MessageBox(PChar(temp_str), '錯誤', 16);
    StatusBar1.Panels[0].Text:='錯誤:abmn檔案不存在。';
    Exit;
  end;
  //--------------------------------------------------------------------------
  if TimeSeriesProcessingOutputPNG_All_CheckBox.Checked then
  begin
    TimeSeriesProcessingSettingsNowJson_Memo.Lines.Strings[21-1] := '"OutputFile04_PNG_All_Enable":"Yes",';
  end;
  if TimeSeriesProcessingOutputPNG_WS_CheckBox.Checked then
  begin
    TimeSeriesProcessingSettingsNowJson_Memo.Lines.Strings[31-1] := '"OutputFile08_PNG_WS_Enable":"Yes",';
  end;
  if TimeSeriesProcessingOutputPNG_MGD_CheckBox.Checked then
  begin
    TimeSeriesProcessingSettingsNowJson_Memo.Lines.Strings[41-1] := '"OutputFile12_PNG_MGD_Enable":"Yes",';
  end;
  if TimeSeriesProcessingOutputPNG_MPR_CheckBox.Checked then
  begin
    TimeSeriesProcessingSettingsNowJson_Memo.Lines.Strings[51-1] := '"OutputFile16_PNG_MPR_Enable":"Yes",';
  end;
  if TimeSeriesProcessingOutputPNG_GD_CheckBox.Checked then
  begin
    TimeSeriesProcessingSettingsNowJson_Memo.Lines.Strings[61-1] := '"OutputFile20_PNG_GD_Enable":"Yes",';
  end;
  if TimeSeriesProcessingOutputPNG_Select_CheckBox.Checked then
  begin
    TimeSeriesProcessingSettingsNowJson_Memo.Lines.Strings[83-1] := '"OutputFile24_PNG_Select_Enable":"Yes",';
  end;
  //--------------------------------------------------------------------------
  if TimeSeriesProcessingSelectFrom_All_RadioButton.Checked then
  begin
    TimeSeriesProcessingSettingsNowJson_Memo.Lines.Strings[63-1] := '"Select_From":"All",';
  end;
  if TimeSeriesProcessingSelectFrom_WS_RadioButton.Checked then
  begin
    TimeSeriesProcessingSettingsNowJson_Memo.Lines.Strings[63-1] := '"Select_From":"WS",';
  end;
  if TimeSeriesProcessingSelectFrom_MGD_RadioButton.Checked then
  begin
    TimeSeriesProcessingSettingsNowJson_Memo.Lines.Strings[63-1] := '"Select_From":"MGD",';
  end;
  if TimeSeriesProcessingSelectFrom_MPR_RadioButton.Checked then
  begin
    TimeSeriesProcessingSettingsNowJson_Memo.Lines.Strings[63-1] := '"Select_From":"MPR",';
  end;
  if TimeSeriesProcessingSelectFrom_GD_RadioButton.Checked then
  begin
    TimeSeriesProcessingSettingsNowJson_Memo.Lines.Strings[63-1] := '"Select_From":"GD",';
  end;
  //--------------------------------------------------------------------------
  TimeSeriesProcessingSettingsNowJson_Memo.Lines.Strings[65-1] := ('"Select_Keep_A_index":['+TimeSeriesProcessingSelectKeepA_Edit.Text+'],');
  TimeSeriesProcessingSettingsNowJson_Memo.Lines.Strings[67-1] := ('"Select_Keep_B_index":['+TimeSeriesProcessingSelectKeepB_Edit.Text+'],');
  TimeSeriesProcessingSettingsNowJson_Memo.Lines.Strings[69-1] := ('"Select_Keep_M_index":['+TimeSeriesProcessingSelectKeepM_Edit.Text+'],');
  TimeSeriesProcessingSettingsNowJson_Memo.Lines.Strings[71-1] := ('"Select_Keep_N_index":['+TimeSeriesProcessingSelectKeepN_Edit.Text+'],');
  //--------------------------------------------------------------------------
  //--------------------------------------------------------------------------
  // 儲存預設JSON檔案
  ForceDirectories('Input_ERTMaker_v299ScsvToUrf');
  TimeSeriesProcessingSettingsNowJson_Memo.Lines.SaveToFile('Input_ERTMaker_v299ScsvToUrf/v299ScsvToUrf.json',TEncoding.UTF8);
  TimeSeriesProcessingSettingsNowJson_Memo.Lines.SaveToFile('Output_ERTMaker_v299ScsvToUrf/Input_v299ScsvToUrf/v299ScsvToUrf.json',TEncoding.UTF8);
  //--------------------------------------------------------------------------
  //--------------------------------------------------------------------------
  // 外部Python程式檢查
  if not FileExists('PythonEnv\Python.exe') then
  begin
    temp_str := '錯誤:' + #13#10 +
      '外部Python環境不存在。';
    Application.MessageBox(PChar(temp_str), '錯誤', 16);
    StatusBar1.Panels[0].Text:='錯誤:外部Python環境不存在。';
    Exit;
  end;
  if not FileExists('ERTMaker_v299ScsvToUrf_v20260217a.cpython-312.pyc') then
  begin
    temp_str := '錯誤:' + #13#10 +
      '外部Python程式不存在。';
    Application.MessageBox(PChar(temp_str), '錯誤', 16);
    StatusBar1.Panels[0].Text:='錯誤:外部Python程式不存在。';
    Exit;
  end;
  //--------------------------------------------------------------------------
  //--------------------------------------------------------------------------
  TimeSeriesProcessingSettingsCmdLog_Memo.Lines.Clear;
  // 使用 TimeSeriesProcessing_AsyncProcess 運行外部程式
  TimeSeriesProcessing_AsyncProcess.Executable:='cmd.exe';
  TimeSeriesProcessing_AsyncProcess.Parameters.Clear;
  TimeSeriesProcessing_AsyncProcess.Parameters.Add('/c');
  TimeSeriesProcessing_AsyncProcess.Parameters.Add('.\PythonEnv\Python.exe -u ERTMaker_v299ScsvToUrf_v20260217a.cpython-312.pyc');
  TimeSeriesProcessing_AsyncProcess.Options:=[poUsePipes] + [poNoConsole];
  TimeSeriesProcessing_AsyncProcess.Execute;
  // 禁用元件，等背景運作完再從事件重新啟用按鈕
  CreateMeshRun_ToolButton.Enabled:=False;
  ForwardModelingRun_ToolButton.Enabled:=False;
  TimeSeriesProcessingRun_ToolButton.Enabled:=False;
  CreateMeshParameters_GroupBox.Enabled:=False;
  ForwardModelingParameters_GroupBox.Enabled:=False;
  TimeSeriesProcessingParameters_GroupBox.Enabled:=False;
  //--------------------------------------------------------------------------
end;

procedure TForm1.TimeSeriesProcessingSelectKeepA_PopupMenu_1_1Click(
  Sender: TObject);
begin
  TimeSeriesProcessingSelectKeepA_Edit.Text := '1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34,35,36,37,38,39,40,41,42,43,44,45,46,47,48,49,50,51,52,53,54,55,56,57,58,59,60,61,62,63,64';
end;

procedure TForm1.TimeSeriesProcessingSelectKeepB_PopupMenu_1_1Click(
  Sender: TObject);
begin
  TimeSeriesProcessingSelectKeepB_Edit.Text := '1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34,35,36,37,38,39,40,41,42,43,44,45,46,47,48,49,50,51,52,53,54,55,56,57,58,59,60,61,62,63,64';
end;

procedure TForm1.TimeSeriesProcessingSelectKeepM_PopupMenu_1_1Click(
  Sender: TObject);
begin
  TimeSeriesProcessingSelectKeepM_Edit.Text := '1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34,35,36,37,38,39,40,41,42,43,44,45,46,47,48,49,50,51,52,53,54,55,56,57,58,59,60,61,62,63,64';
end;

procedure TForm1.TimeSeriesProcessingSelectKeepN_PopupMenu_1_1Click(
  Sender: TObject);
begin
  TimeSeriesProcessingSelectKeepN_Edit.Text := '1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34,35,36,37,38,39,40,41,42,43,44,45,46,47,48,49,50,51,52,53,54,55,56,57,58,59,60,61,62,63,64';
end;

procedure TForm1.TimeSeriesProcessing_AsyncProcessReadData(Sender: TObject);
var
  temp_Buffer:string='';
  temp_BytesAvailable:DWord;
begin
  //--------------------------------------------------------------------------
  // 顯示外部cmd.exe運行內容
  temp_BytesAvailable:=TimeSeriesProcessing_AsyncProcess.Output.NumBytesAvailable;
  if temp_BytesAvailable>0 Then begin
    setlength(temp_Buffer,temp_BytesAvailable);
    TimeSeriesProcessing_AsyncProcess.Output.Read(temp_Buffer[1],temp_BytesAvailable);
    temp_Buffer := StringReplace(temp_Buffer, #13#10, #10, [rfReplaceAll]);
    temp_Buffer := StringReplace(temp_Buffer, #10, #13#10, [rfReplaceAll]);
    TimeSeriesProcessingSettingsCmdLog_Memo.Lines.Add(WinCPToUTF8(temp_Buffer));
  end;
  //--------------------------------------------------------------------------
end;

procedure TForm1.TimeSeriesProcessing_AsyncProcessTerminate(Sender: TObject);
var
  temp_str: AnsiString;
begin
  //--------------------------------------------------------------------------
  // 啟用元件
  CreateMeshRun_ToolButton.Enabled:=True;
  ForwardModelingRun_ToolButton.Enabled:=True;
  TimeSeriesProcessingRun_ToolButton.Enabled:=True;
  CreateMeshParameters_GroupBox.Enabled:=True;
  ForwardModelingParameters_GroupBox.Enabled:=True;
  TimeSeriesProcessingParameters_GroupBox.Enabled:=True;
  //--------------------------------------------------------------------------
  //--------------------------------------------------------------------------
  // 更新狀態列
  //--
  if TimeSeriesProcessingSettingsCmdLog_Memo.Lines.Count=0 Then
  begin
    StatusBar1.Panels[0].Text:='運行時間序列解算...異常結束!';
    Exit;
  end;
  //--
  // 檢查結果ohm
  temp_str:=TimeSeriesProcessingSettingsNowJson_Memo.Lines.Strings[79-1];
  temp_str:=StringReplace(temp_str, '"OutputFile23_Ohm_Select_FileName":"', '', [rfReplaceAll]);
  temp_str:=StringReplace(temp_str, '",', '', [rfReplaceAll]);
  if FileExists(temp_str) then
  begin
    StatusBar1.Panels[0].Text:='運行時間序列解算...完成!';
    // 成功提示
    temp_str := '成功:' + #13#10 +
      '時間序列解算...完成!';
    Application.MessageBox(PChar(temp_str), '提示', 64);
    Exit;
  end
  else
  begin
    StatusBar1.Panels[0].Text:='運行時間序列解算...運作異常，請檢查紀錄!';
    Exit;
  end;
  //--------------------------------------------------------------------------
end;

end.

